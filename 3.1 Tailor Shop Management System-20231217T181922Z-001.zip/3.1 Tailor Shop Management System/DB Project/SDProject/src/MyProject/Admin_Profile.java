package MyProject;

import com.email.durgesh.Email;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Admin_Profile extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;
   
    String From = null;
    String EmailID = null;
    String EmailPassword = null;
    
    public Admin_Profile() {
        initComponents(); 
        EmailID = SE.getText();
        EmailPassword = SEP.getText();
        Show();
    }
    
    public Admin_Profile(String From) {
        initComponents();
        this.From = From;
        EmailID = SE.getText();
        EmailPassword = SEP.getText();
        Show();
    }
    
    public void Show(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql = "Select Information.Name, Information.Gender, Information.MobileNumber, EmployeeDetails.Email, EmployeeDetails.PermanentAddress from Information inner join EmployeeDetails on Information.ID = EmployeeDetails.ID where Information.ID like 'Admin%'";
            PreparedStatement pst = con.prepareStatement(sql);            
            ResultSet rs = pst.executeQuery();
            
            while(rs.next())
            {
                UserName.setText(rs.getString("Name"));
                if(rs.getString("Gender").equals("Male"))
                {
                    Gender.setSelectedIndex(1);
                }else if(rs.getString("Gender").equals("Female")){
                    Gender.setSelectedIndex(2);
                }                    
                Email.setText(rs.getString("Email"));
                MobileNo.setText(rs.getString("MobileNumber"));
                Password.setText(rs.getString("PermanentAddress"));                
            }
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Admin_Profile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void Message()
    {
        try{
            Email email = new Email(EmailID, EmailPassword);

            email.setFrom(EmailID, "Tailor Shop Management System");

            email.setSubject("This email for confirmation.");

            email.setContent("<h2>Your profile has updated successfully !!!</h2>", "text/html");

            email.addRecipient(Email.getText());

            email.send();            
        }

        catch(Exception e)
        {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Enter a valid Email address !");
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        register_gender = new javax.swing.JComboBox<>();
        jpanelsignup = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        UserName = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        Email = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        Gender = new javax.swing.JComboBox<>();
        MobileNo = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        Update = new javax.swing.JButton();
        close = new javax.swing.JButton();
        reset = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        ShowPassword = new javax.swing.JCheckBox();
        ShowConPassword = new javax.swing.JCheckBox();
        Password = new javax.swing.JPasswordField();
        ConfirmationPassword = new javax.swing.JPasswordField();
        jLabel11 = new javax.swing.JLabel();
        SE = new javax.swing.JLabel();
        SEP = new javax.swing.JLabel();

        register_gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male ", "Female" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jpanelsignup.setBackground(new java.awt.Color(255, 255, 255));
        jpanelsignup.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Monotype Corsiva", 0, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Admin Profile");
        jpanelsignup.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, 280, 37));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Username");
        jpanelsignup.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, -1, -1));

        UserName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        UserName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UserNameActionPerformed(evt);
            }
        });
        jpanelsignup.add(UserName, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 233, 31));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Gender");
        jpanelsignup.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 90, 70, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Email Address");
        jpanelsignup.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, -1, -1));

        Email.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmailActionPerformed(evt);
            }
        });
        jpanelsignup.add(Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, 233, 31));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("Mobile number");
        jpanelsignup.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 150, -1, -1));

        Gender.setBackground(new java.awt.Color(249, 245, 242));
        Gender.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<Select>>", "Male", "Female" }));
        jpanelsignup.add(Gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 110, 240, 31));

        MobileNo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        MobileNo.setText("01");
        MobileNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MobileNoActionPerformed(evt);
            }
        });
        jpanelsignup.add(MobileNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 170, 243, 31));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("Password");
        jpanelsignup.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, -1, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("Confimation Password");
        jpanelsignup.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 210, -1, -1));

        Update.setBackground(new java.awt.Color(249, 245, 242));
        Update.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Update.setText("Update");
        Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateActionPerformed(evt);
            }
        });
        jpanelsignup.add(Update, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 310, 90, 40));

        close.setBackground(new java.awt.Color(249, 245, 242));
        close.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        close.setText("Close");
        close.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeActionPerformed(evt);
            }
        });
        jpanelsignup.add(close, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 92, 39));

        reset.setBackground(new java.awt.Color(249, 245, 242));
        reset.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        reset.setText("Reset");
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });
        jpanelsignup.add(reset, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 310, 85, 40));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Logo_mini.png"))); // NOI18N
        jpanelsignup.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 10, -1, 70));

        ShowPassword.setBackground(new java.awt.Color(249, 245, 242));
        ShowPassword.setText("Show Password");
        ShowPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ShowPasswordActionPerformed(evt);
            }
        });
        jpanelsignup.add(ShowPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, 167, -1));

        ShowConPassword.setBackground(new java.awt.Color(249, 245, 242));
        ShowConPassword.setText("Show Confirmation Password");
        ShowConPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ShowConPasswordActionPerformed(evt);
            }
        });
        jpanelsignup.add(ShowConPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 270, -1, -1));

        Password.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PasswordActionPerformed(evt);
            }
        });
        jpanelsignup.add(Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 233, 31));

        ConfirmationPassword.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jpanelsignup.add(ConfirmationPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 230, 243, 31));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Admin_Profile.jpg"))); // NOI18N
        jpanelsignup.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 560, 370));

        SE.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        SE.setForeground(new java.awt.Color(255, 255, 255));
        SE.setText("Email id");
        jpanelsignup.add(SE, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 0, -1));

        SEP.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        SEP.setForeground(new java.awt.Color(255, 255, 255));
        SEP.setText("password");
        SEP.setToolTipText("");
        jpanelsignup.add(SEP, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 0, 0));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpanelsignup, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpanelsignup, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PasswordActionPerformed

    private void ShowConPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ShowConPasswordActionPerformed
        if(ShowConPassword.isSelected())
        {
            ConfirmationPassword.setEchoChar((char) 0);
        }else{
            ConfirmationPassword.setEchoChar('*');
        }
    }//GEN-LAST:event_ShowConPasswordActionPerformed

    private void ShowPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ShowPasswordActionPerformed
        if(ShowPassword.isSelected())
        {
            Password.setEchoChar((char) 0);
        }else{
            Password.setEchoChar('*');
        }
    }//GEN-LAST:event_ShowPasswordActionPerformed

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed
        UserName.setText("");
        Gender.setSelectedIndex(0); 
        Email.setText("");
        MobileNo.setText("");
        Password.setText("");
        ConfirmationPassword.setText("");
    }//GEN-LAST:event_resetActionPerformed

    private void closeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeActionPerformed
        if(From.equals("Sign IN"))
        {
            new Menu().setVisible(true);
        }
        else if(From.equals("Information")){
            new Information().setVisible(true);
        }
        this.setVisible(false);
    }//GEN-LAST:event_closeActionPerformed

    private void UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateActionPerformed
        
        if(UserName.getText().isEmpty() || Gender.getSelectedItem().equals("<<Select>>") || Email.getText().isEmpty() || MobileNo.getText().isEmpty() || Password.getText().isEmpty() || ConfirmationPassword.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Please enter all the information !!!"); 
            
        }else if(!Password.getText().equals(ConfirmationPassword.getText()))
        {
            JOptionPane.showMessageDialog(null, "Password and Confirmation Password must be same !!!"); 
            
        }else{
            
            try{
                long check = Long.parseLong(MobileNo.getText());
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql1 = "update Information set Name = '"+UserName.getText()+"', Gender = '"+(String) Gender.getSelectedItem()+"', MobileNumber = '"+MobileNo.getText()+"' where ID like 'Admin%'";
                String sql2 = "update EmployeeDetails set Email = '"+Email.getText()+"', PermanentAddress = '"+Password.getText()+"' where ID like 'Admin%'";

                PreparedStatement pst = con.prepareStatement(sql1);
                PreparedStatement qst = con.prepareStatement(sql2);

                pst.executeUpdate();
                qst.executeUpdate();
                
                JOptionPane.showMessageDialog(null, "The Profile has been updated !"); 

                Message();
                new Menu().setVisible(true);
                this.setVisible(false);
            
            }catch(SQLException e){

                System.out.println(e);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Enter the valid mobile number !");
            }
        }
    }//GEN-LAST:event_UpdateActionPerformed

    private void MobileNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MobileNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MobileNoActionPerformed

    private void EmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EmailActionPerformed

    private void UserNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UserNameActionPerformed

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin_Profile().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField ConfirmationPassword;
    private javax.swing.JTextField Email;
    private javax.swing.JComboBox<String> Gender;
    private javax.swing.JTextField MobileNo;
    private javax.swing.JPasswordField Password;
    private javax.swing.JLabel SE;
    private javax.swing.JLabel SEP;
    private javax.swing.JCheckBox ShowConPassword;
    private javax.swing.JCheckBox ShowPassword;
    private javax.swing.JButton Update;
    private javax.swing.JTextField UserName;
    private javax.swing.JButton close;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jpanelsignup;
    private javax.swing.JComboBox<String> register_gender;
    private javax.swing.JButton reset;
    // End of variables declaration//GEN-END:variables
}
