package MyProject;

import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public final class Dress_Category extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;
    
    String DressType = null;
    int SelectedID = 0;    
    int LastID = 0;    
        
    public Dress_Category() {
        
        initComponents();        
        All_View();
    }
    
    public void All_View(){
        
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql = "Select * from Dress_Category";
            PreparedStatement pst = con.prepareStatement(sql);
            
            ResultSet rs = pst.executeQuery();
            
            Dress_Category.setModel(new DefaultTableModel(null, new String[] {"Dress ID","Dress Name","Gender","Preparing Cost"}));
            
            while(rs.next())
            {
                LastID = rs.getInt("DressID");
                System.out.println(LastID);
                String tbData[] = {Integer.toString(rs.getInt("DressID")),
                                   rs.getString("DressName"),
                                   rs.getString("GenderType"),
                                   Integer.toString(rs.getInt("PreparingCost"))};
                DefaultTableModel tbModel = (DefaultTableModel) Dress_Category.getModel();
                tbModel.addRow(tbData);
            }
            
            DressName.setText(null);
            Gender.setSelectedIndex(0); 
            PreparingCost.setText(null);
            
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Dress_Category.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        Dress_Category = new javax.swing.JTable();
        MainMenu = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        PreparingCost = new javax.swing.JTextField();
        DressName = new javax.swing.JTextField();
        Add = new javax.swing.JButton();
        Update = new javax.swing.JButton();
        Delete = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        Gender = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        Info_Icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Dress_Category.setBackground(new java.awt.Color(249, 245, 242));
        Dress_Category.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Dress_Category.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Dress ID", "Dress Name", "Gender", "Preparing Cost"
            }
        ));
        Dress_Category.setToolTipText("");
        Dress_Category.setName(""); // NOI18N
        Dress_Category.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Dress_CategoryMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(Dress_Category);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, 640, 270));

        MainMenu.setBackground(new java.awt.Color(249, 245, 242));
        MainMenu.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        MainMenu.setText("Main Menu");
        MainMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MainMenuActionPerformed(evt);
            }
        });
        getContentPane().add(MainMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 530, 200, 50));

        jLabel2.setFont(new java.awt.Font("Monotype Corsiva", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Dress Category");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 30, 380, 40));

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lebel_Small.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 720, 70));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Preparing Cost (with all expenses)");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 400, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Gender");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 400, -1, -1));

        PreparingCost.setBackground(new java.awt.Color(249, 245, 242));
        PreparingCost.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(PreparingCost, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 420, 190, 30));

        DressName.setBackground(new java.awt.Color(249, 245, 242));
        DressName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(DressName, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 420, 200, 30));

        Add.setBackground(new java.awt.Color(249, 245, 242));
        Add.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Add.setText("Add a new");
        Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddActionPerformed(evt);
            }
        });
        getContentPane().add(Add, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 470, 140, 40));

        Update.setBackground(new java.awt.Color(249, 245, 242));
        Update.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Update.setText("Update");
        Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateActionPerformed(evt);
            }
        });
        getContentPane().add(Update, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 470, 140, 40));

        Delete.setBackground(new java.awt.Color(249, 245, 242));
        Delete.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Delete.setText("Delete");
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });
        getContentPane().add(Delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 470, 140, 40));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Dress Name");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 400, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Logo_small.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 10, 70, -1));

        Gender.setBackground(new java.awt.Color(249, 245, 242));
        Gender.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All types", "Male", "Female" }));
        getContentPane().add(Gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 420, 170, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setText(" /=");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 420, 40, 30));

        Info_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Dress_Category.jpg"))); // NOI18N
        getContentPane().add(Info_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 720, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Dress_CategoryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Dress_CategoryMouseClicked
        int i = Dress_Category.getSelectedRow();
        TableModel model = Dress_Category.getModel();
        
        SelectedID = Integer.parseInt((String) model.getValueAt(i, 0));
        DressName.setText((String) model.getValueAt(i, 1));
        DressType = (String) model.getValueAt(i, 2);
        
        if(DressType.equals("Male"))
        {
           Gender.setSelectedIndex(1); 
        }
        else if(DressType.equals("Female"))
        {
           Gender.setSelectedIndex(2); 
        } 
        
        String temp = (String) model.getValueAt(i, 3);
        PreparingCost.setText((String) model.getValueAt(i, 3));
    }//GEN-LAST:event_Dress_CategoryMouseClicked
    
    
    private void MainMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MainMenuActionPerformed
        
        new Menu().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_MainMenuActionPerformed

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
        //Delete from database
        int result = JOptionPane.showConfirmDialog(this,"Do you want to delete ?","Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
                
        if(result == JOptionPane.YES_OPTION){
            
            try{
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql = "delete from Dress_Category where DressID = '"+SelectedID+"'";

                PreparedStatement pst = con.prepareStatement(sql);
                pst.executeUpdate();

                JOptionPane.showMessageDialog(null, "The selected info has been deleted !"); 
            
            }catch(SQLException e){

                System.out.println(e);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Dress_Category.class.getName()).log(Level.SEVERE, null, ex);
            }    

            All_View();              
        }
        
    }//GEN-LAST:event_DeleteActionPerformed

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        //Add to database
        if(DressName.getText().isEmpty() || Gender.getSelectedItem().equals("<<Select>>") || PreparingCost.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Enter the all the Information !");
        }
        else
        {
            if(LastID == 0)
            {
                LastID = 1000;
            }
            LastID++;
            
            try{
                int check = Integer.parseInt(PreparingCost.getText());
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql = "insert into Dress_Category(DressID, DressName, GenderType, PreparingCost) values (?,?,?,?)";

                PreparedStatement pst = con.prepareStatement(sql);

                pst.setInt(1, LastID);
                pst.setString(2, DressName.getText());
                pst.setString(3, (String) Gender.getSelectedItem());
                pst.setInt(4, Integer.parseInt(PreparingCost.getText()));

                pst.executeUpdate();

                JOptionPane.showMessageDialog(null, "The inserted info has been added !"); 

            }catch(SQLException e){

                System.out.println(e);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Enter the valid cost !");
            }

            All_View();   
        }
    }//GEN-LAST:event_AddActionPerformed

    private void UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateActionPerformed
        //Update in database
        if(DressName.getText().isEmpty() || Gender.getSelectedItem().equals("<<Select>>") || PreparingCost.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Enter the all the Information !");
        }
        else
        {
            try{
                int check = Integer.parseInt(PreparingCost.getText());
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);

                String sql = "update Dress_Category set DressName = '"+DressName.getText()+"', GenderType = '"+(String) Gender.getSelectedItem()+"', PreparingCost = '"+Integer.parseInt(PreparingCost.getText())+"' where DressID = '"+SelectedID+"'";

                PreparedStatement pst = con.prepareStatement(sql);

                pst.executeUpdate();

                JOptionPane.showMessageDialog(null, "The updated info has been added !"); 
            
            }catch(SQLException e){

                System.out.println(e);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Enter the valid cost !");
            }

            All_View();   
        }
    }//GEN-LAST:event_UpdateActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Dress_Category().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JButton Delete;
    private javax.swing.JTextField DressName;
    private javax.swing.JTable Dress_Category;
    private javax.swing.JComboBox<String> Gender;
    private javax.swing.JLabel Info_Icon;
    private javax.swing.JButton MainMenu;
    private javax.swing.JTextField PreparingCost;
    private javax.swing.JButton Update;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables

    private String getString(String fromInput) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void TicketGenerate(String text, String text0, String text1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private String getText(String format) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}