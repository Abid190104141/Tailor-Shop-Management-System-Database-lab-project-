package MyProject;

import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public final class Employee_Info extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;
    
    int Last_SI = 0;            
    
    public Employee_Info() {
        
        initComponents();        
        All_View();
    }
    
    public void All_View(){
        
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql = "Select Information.ID, Information.Name, Information.Gender, EmployeeDetails.Rank, EmployeeDetails.Salary from Information inner join EmployeeDetails on Information.ID = EmployeeDetails.ID where Information.ID like 'EI_%'";
            PreparedStatement sst = con.prepareStatement(sql);
            
            ResultSet res = sst.executeQuery();
            EmployeeInfo.setModel(new DefaultTableModel(null, new String[] {"Employee ID","Employee Name","Gender","Rank","Salary"}));
            
            while(res.next())
            {
                String tbData[] = {res.getString("ID"),
                                    res.getString("Name"),
                                    res.getString("Gender"),
                                    res.getString("Rank"),
                                    Integer.toString(res.getInt("Salary"))};
                DefaultTableModel tbModel = (DefaultTableModel) EmployeeInfo.getModel();
                tbModel.addRow(tbData);
            }
            Reset();
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Employee_Info.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 
    
    public void Reset(){
        EmployeeID.setText("EI_100");
        MobileNo.setText("01");
        EmployeeName.setText(null);
        MobileNo_copy.setText("01");
        Email.setText(null);
        ContactAddress.setText(null);
        PermanentAddress.setText(null);
        Gender.setSelectedIndex(0);
        Age.setText(null);
        NID.setText(null);
        Rank.setText(null);
        Salary.setText(null);        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        EmployeeInfo = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Gender = new javax.swing.JComboBox<>();
        ContactAddress = new javax.swing.JTextField();
        EmployeeName = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        Email = new javax.swing.JTextField();
        MobileNo_copy = new javax.swing.JTextField();
        MainMenu = new javax.swing.JButton();
        Add = new javax.swing.JButton();
        Update = new javax.swing.JButton();
        EmployeeID = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        Seach_using_CustomerID = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        MobileNo = new javax.swing.JTextField();
        Seach_using_MobileNo = new javax.swing.JButton();
        All_View = new javax.swing.JButton();
        PermanentAddress = new javax.swing.JTextField();
        Salary = new javax.swing.JTextField();
        Rank = new javax.swing.JTextField();
        NID = new javax.swing.JTextField();
        Age = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        Info_Icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        EmployeeInfo.setBackground(new java.awt.Color(249, 245, 242));
        EmployeeInfo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Employee ID", "Employee Name", "Gender", "Rank", "Salary"
            }
        ));
        EmployeeInfo.setToolTipText("");
        EmployeeInfo.setName(""); // NOI18N
        EmployeeInfo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EmployeeInfoMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(EmployeeInfo);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 640, 230));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Logo_small.png"))); // NOI18N
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 20, 70, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("Permanent Address");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 490, -1, -1));

        jLabel2.setFont(new java.awt.Font("Monotype Corsiva", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Employee Information");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 20, 380, 60));

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lebel_Small.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 720, 90));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("Employee Name");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 430, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Contact Address");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 490, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("Mobile Number");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 430, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Gender");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 550, -1, -1));

        Gender.setBackground(new java.awt.Color(249, 245, 242));
        Gender.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<Select>>", "Male", "Female" }));
        getContentPane().add(Gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 570, -1, 31));

        ContactAddress.setBackground(new java.awt.Color(249, 245, 242));
        ContactAddress.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ContactAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContactAddressActionPerformed(evt);
            }
        });
        getContentPane().add(ContactAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 510, 310, 30));

        EmployeeName.setBackground(new java.awt.Color(249, 245, 242));
        EmployeeName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        EmployeeName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmployeeNameActionPerformed(evt);
            }
        });
        getContentPane().add(EmployeeName, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 450, 220, 30));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("Email ID");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 430, 200, -1));

        Email.setBackground(new java.awt.Color(249, 245, 242));
        Email.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 450, 200, 30));

        MobileNo_copy.setBackground(new java.awt.Color(249, 245, 242));
        MobileNo_copy.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(MobileNo_copy, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 450, 200, 30));

        MainMenu.setBackground(new java.awt.Color(249, 245, 242));
        MainMenu.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        MainMenu.setText("Back");
        MainMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MainMenuActionPerformed(evt);
            }
        });
        getContentPane().add(MainMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 630, 130, 40));

        Add.setBackground(new java.awt.Color(249, 245, 242));
        Add.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Add.setText("Add a new");
        Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddActionPerformed(evt);
            }
        });
        getContentPane().add(Add, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 630, 130, 40));

        Update.setBackground(new java.awt.Color(249, 245, 242));
        Update.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Update.setText("Update");
        Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateActionPerformed(evt);
            }
        });
        getContentPane().add(Update, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 630, 130, 40));

        EmployeeID.setBackground(new java.awt.Color(249, 245, 242));
        EmployeeID.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        EmployeeID.setText("EI_100");
        EmployeeID.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EmployeeIDMouseClicked(evt);
            }
        });
        getContentPane().add(EmployeeID, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 130, 110, 30));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setText("Employee ID");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 110, -1, 20));

        Seach_using_CustomerID.setBackground(new java.awt.Color(249, 245, 242));
        Seach_using_CustomerID.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Seach_using_CustomerID.setText("Search");
        Seach_using_CustomerID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Seach_using_CustomerIDActionPerformed(evt);
            }
        });
        getContentPane().add(Seach_using_CustomerID, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 130, 80, 30));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel14.setText("Mobile Number");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 110, 90, 20));

        MobileNo.setBackground(new java.awt.Color(249, 245, 242));
        MobileNo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        MobileNo.setText("01");
        MobileNo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MobileNoMouseClicked(evt);
            }
        });
        MobileNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MobileNoActionPerformed(evt);
            }
        });
        getContentPane().add(MobileNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 130, 150, 30));

        Seach_using_MobileNo.setBackground(new java.awt.Color(249, 245, 242));
        Seach_using_MobileNo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Seach_using_MobileNo.setText("Search");
        Seach_using_MobileNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Seach_using_MobileNoActionPerformed(evt);
            }
        });
        getContentPane().add(Seach_using_MobileNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 130, 80, 30));

        All_View.setBackground(new java.awt.Color(249, 245, 242));
        All_View.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        All_View.setText("All View");
        All_View.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                All_ViewActionPerformed(evt);
            }
        });
        getContentPane().add(All_View, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 120, 30));

        PermanentAddress.setBackground(new java.awt.Color(249, 245, 242));
        PermanentAddress.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        PermanentAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PermanentAddressActionPerformed(evt);
            }
        });
        getContentPane().add(PermanentAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 510, 320, 30));

        Salary.setBackground(new java.awt.Color(249, 245, 242));
        Salary.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Salary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalaryActionPerformed(evt);
            }
        });
        getContentPane().add(Salary, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 570, 90, 30));

        Rank.setBackground(new java.awt.Color(249, 245, 242));
        Rank.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Rank.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RankActionPerformed(evt);
            }
        });
        getContentPane().add(Rank, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 570, 140, 30));

        NID.setBackground(new java.awt.Color(249, 245, 242));
        NID.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        NID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NIDActionPerformed(evt);
            }
        });
        getContentPane().add(NID, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 570, 200, 30));

        Age.setBackground(new java.awt.Color(249, 245, 242));
        Age.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Age.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgeActionPerformed(evt);
            }
        });
        getContentPane().add(Age, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 570, 70, 30));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("Salary (Taka)");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 550, -1, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("Rank");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 550, -1, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setText("NID No.");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 550, -1, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("Age");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 550, -1, -1));

        Info_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Customer_Info.jpg"))); // NOI18N
        getContentPane().add(Info_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 720, 710));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void EmployeeInfoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EmployeeInfoMouseClicked
        int i = EmployeeInfo.getSelectedRow();
        TableModel model = EmployeeInfo.getModel();
        
        EmployeeID.setText((String) model.getValueAt(i, 0));
        EmployeeName.setText((String) model.getValueAt(i, 1));
        String temp = (String) model.getValueAt(i, 2);
        if(temp.equals("Male"))
        {
            Gender.setSelectedIndex(1);
        }else{
            Gender.setSelectedIndex(2);        
        }
        Rank.setText((String) model.getValueAt(i, 3));
        Salary.setText((String) model.getValueAt(i, 4));
        
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql = "Select Information.MobileNumber, Information.Address, EmployeeDetails.Email, EmployeeDetails.PermanentAddress, EmployeeDetails.Age, EmployeeDetails.NID from Information inner join EmployeeDetails on Information.ID = EmployeeDetails.ID where Information.ID = '"+EmployeeID.getText()+"'";
            PreparedStatement sst = con.prepareStatement(sql);
            
            ResultSet res = sst.executeQuery();
            
            while(res.next())
            {
                MobileNo.setText(res.getString("MobileNumber"));
                MobileNo_copy.setText(res.getString("MobileNumber"));
                Email.setText(res.getString("Email"));
                ContactAddress.setText(res.getString("Address"));
                PermanentAddress.setText(res.getString("PermanentAddress"));
                Age.setText(Integer.toString(res.getInt("Age")));
                NID.setText(res.getString("NID"));
            }
            }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Employee_Info.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_EmployeeInfoMouseClicked
    
    
    private void MainMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MainMenuActionPerformed
        
        new Information().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_MainMenuActionPerformed

    private void UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateActionPerformed
        //Update in database
        if(EmployeeName.getText().isEmpty() || MobileNo_copy.getText().isEmpty() || Email.getText().isEmpty() || ContactAddress.getText().isEmpty() || PermanentAddress.getText().isEmpty() || Gender.getSelectedItem().equals("<<Select>>") || Age.getText().isEmpty() || NID.getText().isEmpty() || Rank.getText().isEmpty() || Salary.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Enter the all the Information !");
        }
        else if(Long.parseLong(MobileNo_copy.getText()) < 1100000000)
        {
            JOptionPane.showMessageDialog(null, "Enter the Mobile Number correctly !");
        }
        else
        {
            try{
                long validity = 0;
                validity = Long.parseLong(MobileNo_copy.getText());
                validity = Long.parseLong(Age.getText());
                validity = Long.parseLong(NID.getText());
                validity = Long.parseLong(Salary.getText());
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);

                String sql1 = "update Information set Name = '"+EmployeeName.getText()+"', Gender = '"+(String) Gender.getSelectedItem()+"', MobileNumber = '"+MobileNo_copy.getText()+"', Address = '"+ContactAddress.getText()+"' where ID = '"+EmployeeID.getText()+"'";
                String sql2 = "update EmployeeDetails set NID = '"+NID.getText()+"', Age = '"+Age.getText()+"', Email = '"+Email.getText()+"', PermanentAddress = '"+PermanentAddress.getText()+"', Rank = '"+Rank.getText()+"', Salary = '"+Salary.getText()+"' where ID = '"+EmployeeID.getText()+"'";
                
                PreparedStatement pst = con.prepareStatement(sql1);
                PreparedStatement qst = con.prepareStatement(sql2);
                
                pst.executeUpdate();
                qst.executeUpdate();

                JOptionPane.showMessageDialog(null, "The updated info has been added !"); 
            
            }catch(SQLException e){

                System.out.println(e);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Enter the valid Information !");
            }  

            All_View(); 
        }
    }//GEN-LAST:event_UpdateActionPerformed

    private void ContactAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContactAddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ContactAddressActionPerformed

    private void EmployeeNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmployeeNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EmployeeNameActionPerformed

    private void EmployeeIDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EmployeeIDMouseClicked
        // TODO add your handling code here:
        All_View();
        Reset();
    }//GEN-LAST:event_EmployeeIDMouseClicked

    private void MobileNoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MobileNoMouseClicked
        // TODO add your handling code here:
        All_View();
        Reset();
    }//GEN-LAST:event_MobileNoMouseClicked

    private void MobileNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MobileNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MobileNoActionPerformed

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        //Add to database
        if(EmployeeName.getText().isEmpty() || MobileNo_copy.getText().isEmpty() || Email.getText().isEmpty() || ContactAddress.getText().isEmpty() || PermanentAddress.getText().isEmpty() || Gender.getSelectedItem().equals("<<Select>>") || Age.getText().isEmpty() || NID.getText().isEmpty() || Rank.getText().isEmpty() || Salary.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Enter the all the Information !");
        }
        else if(Long.parseLong(MobileNo_copy.getText()) < 1100000000)
        {
            JOptionPane.showMessageDialog(null, "Enter the Mobile Number correctly !");
        }
        else
        {
            try{
                long validity = 0;
                validity = Long.parseLong(MobileNo_copy.getText());
                validity = Long.parseLong(Age.getText());
                validity = Long.parseLong(NID.getText());
                validity = Long.parseLong(Salary.getText());
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql1 = "Select count(ID) as EmployeeID from Information where ID like 'EI_%'";
            
                PreparedStatement pst = con.prepareStatement(sql1);
                ResultSet rs = pst.executeQuery();
            
                while(rs.next())
                {
                    Last_SI = rs.getInt("EmployeeID");
                }
                String ID;
                if(Last_SI == 0)
                {
                    ID = "EI_" + Integer.toString(10001);
                }
                else{
                    ID = "EI_" + Integer.toString(10001+Last_SI);
                }
                String sql2 = "insert into Information(ID, Name, Gender, MobileNumber, Address) values ('"+ID+"','"+EmployeeName.getText()+"','"+(String) Gender.getSelectedItem()+"','"+MobileNo_copy.getText()+"','"+ContactAddress.getText()+"')";
                String sql3 = "insert into EmployeeDetails(ID, NID, Age, Email, PermanentAddress, Rank, Salary) values ('"+ID+"','"+NID.getText()+"','"+Age.getText()+"','"+Email.getText()+"','"+PermanentAddress.getText()+"','"+Rank.getText()+"','"+Salary.getText()+"')";
                
                PreparedStatement qst = con.prepareStatement(sql2);
                PreparedStatement rst = con.prepareStatement(sql3);
                
                qst.executeUpdate();
                rst.executeUpdate();
                
                JOptionPane.showMessageDialog(null, "The inserted info has been added !"); 

            }catch(SQLException e){

                System.out.println(e);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Enter the valid Information !");
            }

            All_View();
        }
    }//GEN-LAST:event_AddActionPerformed

    private void Seach_using_CustomerIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Seach_using_CustomerIDActionPerformed
        if(EmployeeID.getText().trim().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Enter the Employee ID !"); 
        }else{
        
            try{
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql = "Select Information.ID, Information.Name, Information.Gender, EmployeeDetails.Rank, EmployeeDetails.Salary from Information inner join EmployeeDetails on Information.ID = EmployeeDetails.ID where Information.ID = '"+EmployeeID.getText()+"'";
                PreparedStatement pst = con.prepareStatement(sql);            
                ResultSet res = pst.executeQuery();
                EmployeeInfo.setModel(new DefaultTableModel(null, new String[] {"Employee ID","Employee Name","Gender","Rank","Salary"}));
            
                while(res.next())
                {
                    String tbData[] = {res.getString("ID"),
                                    res.getString("Name"),
                                    res.getString("Gender"),
                                    res.getString("Rank"),
                                    Integer.toString(res.getInt("Salary"))};
                DefaultTableModel tbModel = (DefaultTableModel) EmployeeInfo.getModel();
                tbModel.addRow(tbData);
                }

                EmployeeName.setText(null);
                MobileNo_copy.setText("01");
                Email.setText(null);
                ContactAddress.setText(null);
                PermanentAddress.setText(null);
                Gender.setSelectedIndex(0);
                Age.setText(null);
                NID.setText(null);
                Rank.setText(null);
                Salary.setText(null); 

            }catch(SQLException e){

                System.out.println(e);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Employee_Info.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_Seach_using_CustomerIDActionPerformed

    private void Seach_using_MobileNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Seach_using_MobileNoActionPerformed
        if(MobileNo.getText().trim().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Enter the mobile number !"); 
        }else{
            try{
                long check = Long.parseLong(MobileNo.getText());
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql = "Select Information.ID, Information.Name, Information.Gender, EmployeeDetails.Rank, EmployeeDetails.Salary from Information inner join EmployeeDetails on Information.ID = EmployeeDetails.ID where Information.MobileNumber = '"+MobileNo.getText()+"'";
                PreparedStatement pst = con.prepareStatement(sql);            
                ResultSet res = pst.executeQuery();
                EmployeeInfo.setModel(new DefaultTableModel(null, new String[] {"Employee ID","Employee Name","Gender","Rank","Salary"}));
            
                while(res.next())
                {
                    String tbData[] = {res.getString("ID"),
                                    res.getString("Name"),
                                    res.getString("Gender"),
                                    res.getString("Rank"),
                                    Integer.toString(res.getInt("Salary"))};
                DefaultTableModel tbModel = (DefaultTableModel) EmployeeInfo.getModel();
                tbModel.addRow(tbData);
                }

                EmployeeName.setText(null);
                MobileNo_copy.setText("01");
                Email.setText(null);
                ContactAddress.setText(null);
                PermanentAddress.setText(null);
                Gender.setSelectedIndex(0);
                Age.setText(null);
                NID.setText(null);
                Rank.setText(null);
                Salary.setText(null);                
                
            }catch(SQLException e){

                System.out.println(e);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Enter the valid mobile number !");
            }
        }
    }//GEN-LAST:event_Seach_using_MobileNoActionPerformed

    private void All_ViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_All_ViewActionPerformed
        All_View();
        Reset();
    }//GEN-LAST:event_All_ViewActionPerformed

    private void SalaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalaryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SalaryActionPerformed

    private void PermanentAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PermanentAddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PermanentAddressActionPerformed

    private void RankActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RankActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RankActionPerformed

    private void NIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NIDActionPerformed

    private void AgeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AgeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Employee_Info().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JTextField Age;
    private javax.swing.JButton All_View;
    private javax.swing.JTextField ContactAddress;
    private javax.swing.JTextField Email;
    private javax.swing.JTextField EmployeeID;
    private javax.swing.JTable EmployeeInfo;
    private javax.swing.JTextField EmployeeName;
    private javax.swing.JComboBox<String> Gender;
    private javax.swing.JLabel Info_Icon;
    private javax.swing.JButton MainMenu;
    private javax.swing.JTextField MobileNo;
    private javax.swing.JTextField MobileNo_copy;
    private javax.swing.JTextField NID;
    private javax.swing.JTextField PermanentAddress;
    private javax.swing.JTextField Rank;
    private javax.swing.JTextField Salary;
    private javax.swing.JButton Seach_using_CustomerID;
    private javax.swing.JButton Seach_using_MobileNo;
    private javax.swing.JButton Update;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables

    private String getString(String fromInput) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void TicketGenerate(String text, String text0, String text1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private String getText(String format) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}