package MyProject;

import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public final class Cancelled_Orders extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;
    
    String OrderType = "Cancelled";
    String DressID = null;
    String Date1 = null;
    String Date2 = null;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    
    public Cancelled_Orders() {
        
        initComponents();
        All_View();  
    }
    
    public void All_View(){
        
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql = "Select * from All_Orders where OrderType = '"+OrderType+"' order by DeliveryDate desc";
            PreparedStatement pst = con.prepareStatement(sql);
            
            ResultSet res = pst.executeQuery();            
            
            All_Transaction_Analysis();
            All_Order_Counting();
            CancelledOrders.setModel(new DefaultTableModel(null, new String[] {"Order ID","Customer ID","Dress ID","Order Date","Cancellation Date","Penalty Rate"}));
            First_Date.setCalendar(null);
            Last_Date.setCalendar(null);
            while(res.next())
            {
                String tbData[] = {Integer.toString(res.getInt("OrderID")),
                                    res.getString("ID"),
                                    Integer.toString(res.getInt("DressID")),                                    
                                    res.getString("OrderDate"),
                                    res.getString("DeliveryDate"),
                                    Integer.toString(res.getInt("Total"))};
                DefaultTableModel tbModel = (DefaultTableModel) CancelledOrders.getModel();
                tbModel.addRow(tbData);
            }
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Customer_Info.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void All_Transaction_Analysis(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            
            String sql = "select sum(Total) as Total_Amount from All_Orders where OrderType = '"+OrderType+"'";
            
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            
            while(rs.next())
            {
                Total_Penalty.setText(Integer.toString(rs.getInt("Total_Amount")));
            }
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    public void Specific_Transaction_Analysis_by_Date(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql;
            
            Date1 = sdf.format(First_Date.getDate());                
            Date2 = sdf.format(Last_Date.getDate());
            Date1 = Date1 + " 00:00:00.000";
            Date2 = Date2 + " 23:59:59.000";
            sql = "select sum(Total) as Total_Amount from All_Orders where OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"' and OrderType = '"+OrderType+"'";
            
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            
            while(rs.next())
            {
                Total_Penalty.setText(Integer.toString(rs.getInt("Total_Amount")));
            }
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    public void Specific_Transaction_Analysis_by_CID(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql = "select sum(Total) as Total_Amount from All_Orders where ID = '"+CustomerID.getText()+"' and OrderType = '"+OrderType+"'";
             
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            
            while(rs.next())
            {
                Total_Penalty.setText(Integer.toString(rs.getInt("Total_Amount")));
            }
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    public void All_Order_Counting(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            
            String sql = "Select count(OrderID) as Cancelled_Orders from All_Orders where OrderType = '"+OrderType+"'";
            
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            
            while(rs.next())
            {
                Cancelled_Orders_no.setText(Integer.toString(rs.getInt("Cancelled_Orders")));
            }
        }catch(SQLException e){
        
            System.out.println(e);
            JOptionPane.showMessageDialog(null, e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    public void Specific_Order_Counting_by_Date(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            
            Date1 = sdf.format(First_Date.getDate());                
            Date2 = sdf.format(Last_Date.getDate());
            Date1 = Date1 + " 00:00:00.000";
            Date2 = Date2 + " 23:59:59.000";
            String sql = "Select count(OrderID) as Cancelled_Orders from All_Orders where OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"' and OrderType = '"+OrderType+"'";
            
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            
            while(rs.next())
            {
                Cancelled_Orders_no.setText(Integer.toString(rs.getInt("Cancelled_Orders")));
            }
            
        }catch(SQLException e){
        
            System.out.println(e);
            JOptionPane.showMessageDialog(null, e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    public void Specific_Order_Counting_by_CID(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            
            String sql = "Select count(OrderID) as Cancelled_Orders from All_Orders where ID = '"+CustomerID.getText()+"' and OrderType = '"+OrderType+"'";
            
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            
            while(rs.next())
            {
                Cancelled_Orders_no.setText(Integer.toString(rs.getInt("Cancelled_Orders")));
            }
            
        }catch(SQLException e){
        
            System.out.println(e);
            JOptionPane.showMessageDialog(null, e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    public void Set_Customer_Info(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);

            String sql = "Select * from Information where ID ='"+CustomerID.getText()+"'";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();            

            while(rs.next())
            {
                CustomerName.setText(rs.getString("Name"));
                MobileNo.setText(rs.getString("MobileNumber"));
                Address.setText(rs.getString("Address"));
            }            

        }catch(SQLException e){
            System.out.println(e);
        }catch(Exception e){
            System.out.println(e);
        }  
    }
    
    public void Reset(){
        CustomerID.setText("CI_100");
        OrderID.setText(null);
        MobileNo.setText("01");
        DressName.setText(null);
        CustomerName.setText(null);
        Address.setText(null);
        MobileNo_copy.setText("01");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        CancelledOrders = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        MobileNo_copy = new javax.swing.JTextField();
        Back = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        Address = new javax.swing.JTextField();
        CustomerName = new javax.swing.JTextField();
        DressName = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        OrderID = new javax.swing.JTextField();
        Seach_using_OrderID = new javax.swing.JButton();
        CustomerID = new javax.swing.JTextField();
        Seach_using_CustomerID = new javax.swing.JButton();
        MobileNo = new javax.swing.JTextField();
        Seach_using_MobileNo = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        Seach_using_Date = new javax.swing.JButton();
        First_Date = new com.toedter.calendar.JDateChooser();
        Last_Date = new com.toedter.calendar.JDateChooser();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        All_View = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        Cancelled_Orders_no = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        Total_Penalty = new javax.swing.JTextField();
        Info_Icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        CancelledOrders.setBackground(new java.awt.Color(249, 245, 242));
        CancelledOrders.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        CancelledOrders.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Order ID", "Customer ID", "Dress ID", "Order Date", "Cancellation Date", "Penalty Rate"
            }
        ));
        CancelledOrders.setToolTipText("");
        CancelledOrders.setName(""); // NOI18N
        CancelledOrders.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CancelledOrdersMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(CancelledOrders);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 1070, 230));

        jLabel2.setFont(new java.awt.Font("Monotype Corsiva", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Cancelled Order List");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 490, 70));

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lebel_Bar.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 1110, 90));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Phone Number");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 430, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Customer Name");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 430, -1, -1));

        MobileNo_copy.setEditable(false);
        MobileNo_copy.setBackground(new java.awt.Color(249, 245, 242));
        MobileNo_copy.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        MobileNo_copy.setText("01");
        getContentPane().add(MobileNo_copy, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 450, 160, 30));

        Back.setBackground(new java.awt.Color(249, 245, 242));
        Back.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Back.setText("Back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });
        getContentPane().add(Back, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 510, 150, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Logo_mini.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 20, 70, -1));

        Address.setEditable(false);
        Address.setBackground(new java.awt.Color(249, 245, 242));
        Address.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(Address, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 450, 220, 30));

        CustomerName.setEditable(false);
        CustomerName.setBackground(new java.awt.Color(249, 245, 242));
        CustomerName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        CustomerName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CustomerNameActionPerformed(evt);
            }
        });
        getContentPane().add(CustomerName, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 450, 220, 30));

        DressName.setEditable(false);
        DressName.setBackground(new java.awt.Color(249, 245, 242));
        DressName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(DressName, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 450, 160, 30));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("Contact Address");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 430, -1, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("Dress Name");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 430, -1, -1));

        OrderID.setBackground(new java.awt.Color(249, 245, 242));
        OrderID.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        OrderID.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OrderIDMouseClicked(evt);
            }
        });
        getContentPane().add(OrderID, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 130, 90, 30));

        Seach_using_OrderID.setBackground(new java.awt.Color(249, 245, 242));
        Seach_using_OrderID.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Seach_using_OrderID.setText("Search");
        Seach_using_OrderID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Seach_using_OrderIDActionPerformed(evt);
            }
        });
        getContentPane().add(Seach_using_OrderID, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 130, -1, 30));

        CustomerID.setBackground(new java.awt.Color(249, 245, 242));
        CustomerID.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        CustomerID.setText("CI_100");
        CustomerID.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CustomerIDMouseClicked(evt);
            }
        });
        getContentPane().add(CustomerID, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 130, 100, 30));

        Seach_using_CustomerID.setBackground(new java.awt.Color(249, 245, 242));
        Seach_using_CustomerID.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Seach_using_CustomerID.setText("Search");
        Seach_using_CustomerID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Seach_using_CustomerIDActionPerformed(evt);
            }
        });
        getContentPane().add(Seach_using_CustomerID, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 130, 80, 30));

        MobileNo.setBackground(new java.awt.Color(249, 245, 242));
        MobileNo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        MobileNo.setText("01");
        MobileNo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MobileNoMouseClicked(evt);
            }
        });
        MobileNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MobileNoActionPerformed(evt);
            }
        });
        getContentPane().add(MobileNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 130, 160, 30));

        Seach_using_MobileNo.setBackground(new java.awt.Color(249, 245, 242));
        Seach_using_MobileNo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Seach_using_MobileNo.setText("Search");
        Seach_using_MobileNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Seach_using_MobileNoActionPerformed(evt);
            }
        });
        getContentPane().add(Seach_using_MobileNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 130, 80, 30));

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel24.setText("Mobile Number");
        getContentPane().add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 110, 90, 20));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel25.setText("Customer ID");
        getContentPane().add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 110, -1, 20));

        jLabel26.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel26.setText("Order ID");
        getContentPane().add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 110, -1, 20));

        Seach_using_Date.setBackground(new java.awt.Color(249, 245, 242));
        Seach_using_Date.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Seach_using_Date.setText("Search");
        Seach_using_Date.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Seach_using_DateActionPerformed(evt);
            }
        });
        getContentPane().add(Seach_using_Date, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 130, -1, 30));

        First_Date.setBackground(new java.awt.Color(249, 245, 242));
        First_Date.setDateFormatString("yyyy-MM-dd");
        First_Date.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(First_Date, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, 170, 30));

        Last_Date.setBackground(new java.awt.Color(249, 245, 242));
        Last_Date.setDateFormatString("yyyy-MM-dd");
        Last_Date.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(Last_Date, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 140, 170, 30));

        jLabel27.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel27.setText("First Date : ");
        getContentPane().add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 110, 70, 30));

        jLabel28.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel28.setText("Last Date : ");
        getContentPane().add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, 70, 30));

        All_View.setBackground(new java.awt.Color(249, 245, 242));
        All_View.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        All_View.setText("All View");
        All_View.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                All_ViewActionPerformed(evt);
            }
        });
        getContentPane().add(All_View, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, 30));

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel22.setText("Total Cancelled Orders");
        getContentPane().add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, -1, 20));

        Cancelled_Orders_no.setEditable(false);
        Cancelled_Orders_no.setBackground(new java.awt.Color(249, 245, 242));
        Cancelled_Orders_no.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Cancelled_Orders_no.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cancelled_Orders_noActionPerformed(evt);
            }
        });
        getContentPane().add(Cancelled_Orders_no, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, 130, 30));

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel33.setText("Total Penalty");
        getContentPane().add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 430, 120, 20));

        Total_Penalty.setEditable(false);
        Total_Penalty.setBackground(new java.awt.Color(249, 245, 242));
        Total_Penalty.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(Total_Penalty, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 450, 130, 30));

        Info_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/large.jpg"))); // NOI18N
        getContentPane().add(Info_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1110, 570));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CancelledOrdersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CancelledOrdersMouseClicked
        int i = CancelledOrders.getSelectedRow();
        TableModel model = CancelledOrders.getModel();
        
        OrderID.setText((String) model.getValueAt(i, 0));
        CustomerID.setText((String) model.getValueAt(i, 1));
        DressID = (String) model.getValueAt(i, 2);
        
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql1 = "Select * from Information where ID = '"+CustomerID.getText()+"'";;
            String sql2 = "Select * from Dress_Category where DressID = '"+Integer.parseInt(DressID)+"'";;
            
            PreparedStatement pst = con.prepareStatement(sql1);            
            PreparedStatement sst = con.prepareStatement(sql2);            
            
            ResultSet rs = pst.executeQuery();
            ResultSet res = sst.executeQuery();
            
            while(rs.next())
            {
                CustomerName.setText(rs.getString("Name"));
                MobileNo.setText(rs.getString("MobileNumber"));
                MobileNo_copy.setText(rs.getString("MobileNumber"));
                Address.setText(rs.getString("Address"));
            }
            while(res.next())
            {
                DressName.setText(res.getString("DressName"));
            }
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Customer_Info.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_CancelledOrdersMouseClicked
    
    
    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
       
        new All_Orders().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BackActionPerformed

    private void CustomerNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CustomerNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CustomerNameActionPerformed

    private void MobileNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MobileNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MobileNoActionPerformed

    private void OrderIDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OrderIDMouseClicked
        // TODO add your handling code here:
        All_View();
        Reset();
    }//GEN-LAST:event_OrderIDMouseClicked

    private void CustomerIDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustomerIDMouseClicked
        // TODO add your handling code here:
        All_View();
        Reset();
    }//GEN-LAST:event_CustomerIDMouseClicked

    private void MobileNoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MobileNoMouseClicked
        // TODO add your handling code here:
        All_View();
        Reset();        
    }//GEN-LAST:event_MobileNoMouseClicked

    private void Seach_using_OrderIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Seach_using_OrderIDActionPerformed
        if(OrderID.getText().trim().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter the Order ID !");
        }else{
            try{
                int check = Integer.parseInt(OrderID.getText());
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql = "Select * from All_Orders where OrderID ='"+Integer.parseInt(OrderID.getText())+"' and OrderType = '"+OrderType+"' order by DeliveryDate desc";
                PreparedStatement pst = con.prepareStatement(sql);

                ResultSet res = pst.executeQuery();            
                CancelledOrders.setModel(new DefaultTableModel(null, new String[] {"Order ID","Customer ID","Dress ID","Order Date","Cancellation Date","Penalty Rate"}));

                while(res.next())
                {
                    String tbData[] = {Integer.toString(res.getInt("OrderID")),
                                        res.getString("ID"),
                                        Integer.toString(res.getInt("DressID")),                                    
                                        res.getString("OrderDate"),
                                        res.getString("DeliveryDate"),
                                        Integer.toString(res.getInt("Total"))};
                    DefaultTableModel tbModel = (DefaultTableModel) CancelledOrders.getModel();
                    tbModel.addRow(tbData);
                    CustomerID.setText(res.getString("ID"));
                    Set_Customer_Info();
                }                            
                Specific_Transaction_Analysis_by_CID();
                Specific_Order_Counting_by_CID();

            }catch(SQLException e){

                System.out.println(e);
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Enter the Valid Order ID !");
                OrderID.setText(null);
                System.out.println(e);
            }
        }
    }//GEN-LAST:event_Seach_using_OrderIDActionPerformed

    private void Seach_using_CustomerIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Seach_using_CustomerIDActionPerformed
        if(CustomerID.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter the Customer ID !");
        }else{
            try{
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql = "Select * from All_Orders where ID ='"+CustomerID.getText()+"' and OrderType = '"+OrderType+"' order by DeliveryDate desc";
                PreparedStatement pst = con.prepareStatement(sql);

                ResultSet res = pst.executeQuery();            
                Specific_Transaction_Analysis_by_CID();
                Specific_Order_Counting_by_CID();        
                CancelledOrders.setModel(new DefaultTableModel(null, new String[] {"Order ID","Customer ID","Dress ID","Order Date","Cancellation Date","Penalty Rate"}));

                while(res.next())
                {
                    String tbData[] = {Integer.toString(res.getInt("OrderID")),
                                        res.getString("ID"),
                                        Integer.toString(res.getInt("DressID")),                                    
                                        res.getString("OrderDate"),
                                        res.getString("DeliveryDate"),
                                        Integer.toString(res.getInt("Total"))};
                    DefaultTableModel tbModel = (DefaultTableModel) CancelledOrders.getModel();
                    tbModel.addRow(tbData);
                    Set_Customer_Info();
                }

            }catch(SQLException e){

                System.out.println(e);
            }catch(Exception e){
                System.out.println(e);
            }
        }
    }//GEN-LAST:event_Seach_using_CustomerIDActionPerformed

    private void Seach_using_MobileNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Seach_using_MobileNoActionPerformed
        if(MobileNo.getText().trim().isEmpty()){
            JOptionPane.showMessageDialog(null, "Enter the Mobile Number !");
        }else{
            try{
                long check = Long.parseLong(MobileNo.getText());
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                
                String sql = "Select Information.ID, All_Orders.OrderID, All_Orders.DressID, All_Orders.OrderDate, All_Orders.DeliveryDate, All_Orders.Rest, All_Orders.Total, All_Orders.Discount from Information inner join All_Orders on Information.ID = All_Orders.CustomerID where MobileNumber ='"+MobileNo.getText()+"' and OrderType = '"+OrderType+"' order by OrderDate asc";
                PreparedStatement pst = con.prepareStatement(sql);
                ResultSet rs = pst.executeQuery();            
                CancelledOrders.setModel(new DefaultTableModel(null, new String[] {"Order ID","Customer ID","Dress ID","Order Date","Delivery Date","Rest Amount","Cost","Discount (%)"}));
                while(rs.next())
                {
                    String tbData[] = {Integer.toString(rs.getInt("OrderID")),
                                        rs.getString("ID"),
                                        Integer.toString(rs.getInt("DressID")),                                    
                                        rs.getString("OrderDate"),
                                        rs.getString("DeliveryDate"),
                                        Integer.toString(rs.getInt("Rest")),
                                        Integer.toString(rs.getInt("Total")),
                                        Integer.toString(rs.getInt("Discount"))};
                    DefaultTableModel tbModel = (DefaultTableModel) CancelledOrders.getModel();
                    tbModel.addRow(tbData);
                    CustomerID.setText(rs.getString("ID"));
                    Set_Customer_Info();
                }            
                Specific_Transaction_Analysis_by_CID();
                Specific_Order_Counting_by_CID();
                
            }catch(SQLException e){

                System.out.println(e);
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Enter the Valid Mobile Number !");
                MobileNo.setText("01");
                System.out.println(e);
            }
        }
    }//GEN-LAST:event_Seach_using_MobileNoActionPerformed

    private void Seach_using_DateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Seach_using_DateActionPerformed
        try{
            SimpleDateFormat tdf = new SimpleDateFormat("yyyy-MM-dd");
            String Date1 = tdf.format(First_Date.getDate());
            String Date2 = tdf.format(Last_Date.getDate());
            Date1 = Date1 + " 00:00:00.000";
            Date2 = Date2 + " 23:59:59.000";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql = "Select * from All_Orders where DeliveryDate >= '"+Date1+"' and DeliveryDate <= '"+Date2+"' and OrderType = '"+OrderType+"' order by DeliveryDate desc";
            PreparedStatement pst = con.prepareStatement(sql);

            ResultSet res = pst.executeQuery();
            Specific_Transaction_Analysis_by_Date();
            Specific_Order_Counting_by_Date();        
            CancelledOrders.setModel(new DefaultTableModel(null, new String[] {"Order ID","Customer ID","Dress ID","Order Date","Cancellation Date","Penalty Rate"}));
            while(res.next())
            {
                String tbData[] = {Integer.toString(res.getInt("OrderID")),
                                    res.getString("ID"),
                                    Integer.toString(res.getInt("DressID")),                                    
                                    res.getString("OrderDate"),
                                    res.getString("DeliveryDate"),
                                    Integer.toString(res.getInt("Total"))};
                DefaultTableModel tbModel = (DefaultTableModel) CancelledOrders.getModel();
                tbModel.addRow(tbData);
            }

        }catch(SQLException e){

            System.out.println(e);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Select the specific date !");
        }
    }//GEN-LAST:event_Seach_using_DateActionPerformed

    private void All_ViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_All_ViewActionPerformed
        All_View();
        Reset();
    }//GEN-LAST:event_All_ViewActionPerformed

    private void Cancelled_Orders_noActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Cancelled_Orders_noActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Cancelled_Orders_noActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Cancelled_Orders().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Address;
    private javax.swing.JButton All_View;
    private javax.swing.JButton Back;
    private javax.swing.JTable CancelledOrders;
    private javax.swing.JTextField Cancelled_Orders_no;
    private javax.swing.JTextField CustomerID;
    private javax.swing.JTextField CustomerName;
    private javax.swing.JTextField DressName;
    private com.toedter.calendar.JDateChooser First_Date;
    private javax.swing.JLabel Info_Icon;
    private com.toedter.calendar.JDateChooser Last_Date;
    private javax.swing.JTextField MobileNo;
    private javax.swing.JTextField MobileNo_copy;
    private javax.swing.JTextField OrderID;
    private javax.swing.JButton Seach_using_CustomerID;
    private javax.swing.JButton Seach_using_Date;
    private javax.swing.JButton Seach_using_MobileNo;
    private javax.swing.JButton Seach_using_OrderID;
    private javax.swing.JTextField Total_Penalty;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables

    private String getString(String fromInput) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void TicketGenerate(String text, String text0, String text1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private String getText(String format) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}