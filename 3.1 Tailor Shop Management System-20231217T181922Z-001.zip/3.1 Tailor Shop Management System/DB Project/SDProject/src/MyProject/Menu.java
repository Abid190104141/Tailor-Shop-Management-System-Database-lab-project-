package MyProject;

import java.awt.Cursor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Menu extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;

    public Menu() {
        initComponents();  
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Information = new javax.swing.JButton();
        All_Orders = new javax.swing.JButton();
        Transaction = new javax.swing.JButton();
        Dress_Category = new javax.swing.JButton();
        Expense = new javax.swing.JButton();
        New_Order = new javax.swing.JButton();
        Exit = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Menu_icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Main Menu");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Information.setBackground(new java.awt.Color(249, 245, 242));
        Information.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Information.setText("Information Panel");
        Information.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                InformationMouseMoved(evt);
            }
        });
        Information.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InformationActionPerformed(evt);
            }
        });
        getContentPane().add(Information, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 450, 230, 50));

        All_Orders.setBackground(new java.awt.Color(249, 245, 242));
        All_Orders.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        All_Orders.setText("All Orders List");
        All_Orders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                All_OrdersActionPerformed(evt);
            }
        });
        getContentPane().add(All_Orders, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 210, 230, 50));

        Transaction.setBackground(new java.awt.Color(249, 245, 242));
        Transaction.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Transaction.setText("Transaction");
        Transaction.setToolTipText("");
        Transaction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TransactionActionPerformed(evt);
            }
        });
        getContentPane().add(Transaction, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 270, 230, 50));

        Dress_Category.setBackground(new java.awt.Color(249, 245, 242));
        Dress_Category.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Dress_Category.setText("Dress Category");
        Dress_Category.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Dress_CategoryActionPerformed(evt);
            }
        });
        getContentPane().add(Dress_Category, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 390, 230, 50));

        Expense.setBackground(new java.awt.Color(249, 245, 242));
        Expense.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Expense.setText("Expense");
        Expense.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExpenseActionPerformed(evt);
            }
        });
        getContentPane().add(Expense, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 330, 230, 50));

        New_Order.setBackground(new java.awt.Color(249, 245, 242));
        New_Order.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        New_Order.setText("New Order");
        New_Order.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                New_OrderMouseMoved(evt);
            }
        });
        New_Order.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                New_OrderActionPerformed(evt);
            }
        });
        getContentPane().add(New_Order, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 150, 230, 50));

        Exit.setBackground(new java.awt.Color(249, 245, 242));
        Exit.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Exit.setText("Exit");
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });
        getContentPane().add(Exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 510, 230, 50));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Logo_large.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 190, 260, 300));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Title.png"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 740, 110));

        Menu_icon.setBackground(new java.awt.Color(255, 255, 255));
        Menu_icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Menu.jpg"))); // NOI18N
        getContentPane().add(Menu_icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, 590));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Dress_CategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Dress_CategoryActionPerformed
        
        new Dress_Category().setVisible(true);
        this.setVisible(false);       
    }//GEN-LAST:event_Dress_CategoryActionPerformed

    private void ExpenseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExpenseActionPerformed
        
        new Expense().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_ExpenseActionPerformed

    private void InformationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InformationActionPerformed
        
        new Information().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_InformationActionPerformed

    private void All_OrdersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_All_OrdersActionPerformed
        
        new All_Orders().setVisible(true);
        this.setVisible(false);        
    }//GEN-LAST:event_All_OrdersActionPerformed

    private void TransactionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TransactionActionPerformed
       
        new Transaction().setVisible(true);
        this.setVisible(false);         
    }//GEN-LAST:event_TransactionActionPerformed

    private void ExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitActionPerformed
        
        int result = JOptionPane.showConfirmDialog(this,"Do you want to close ?","Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
                
        if(result == JOptionPane.YES_OPTION){
           
              System.exit(0);              
        }   
    }//GEN-LAST:event_ExitActionPerformed

    private void InformationMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_InformationMouseMoved
        
        Cursor cursor;
        cursor = new Cursor(Cursor.HAND_CURSOR);
        New_Order.setCursor(cursor);
        Dress_Category.setCursor(cursor);
        Expense.setCursor(cursor);
        Information.setCursor(cursor);
        All_Orders.setCursor(cursor);
        Transaction.setCursor(cursor);
        Exit.setCursor(cursor);
    }//GEN-LAST:event_InformationMouseMoved

    private void New_OrderMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_New_OrderMouseMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_New_OrderMouseMoved

    private void New_OrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_New_OrderActionPerformed
        new New_Order().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_New_OrderActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
            
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton All_Orders;
    private javax.swing.JButton Dress_Category;
    private javax.swing.JButton Exit;
    private javax.swing.JButton Expense;
    private javax.swing.JButton Information;
    private javax.swing.JLabel Menu_icon;
    private javax.swing.JButton New_Order;
    private javax.swing.JButton Transaction;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    // End of variables declaration//GEN-END:variables
}
