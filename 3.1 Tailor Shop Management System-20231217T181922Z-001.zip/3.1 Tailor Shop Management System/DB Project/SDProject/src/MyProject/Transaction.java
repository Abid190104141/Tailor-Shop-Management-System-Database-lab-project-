package MyProject;

import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public final class Transaction extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;

    String Order_Date = null;
    String Delivery_Date = null;
    String Date1 = null;
    String Date2 = null;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
    public Transaction(){
        
        initComponents();
        Date date = new Date();
        All_View(); 
    }
    
    public void All_View(){
        
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql = "select sum(Total) as Total_Amount from All_Orders";
            PreparedStatement ast = con.prepareStatement(sql);
            ResultSet aes = ast.executeQuery();
            while(aes.next())
            {
                Total_Preparing_Cost.setText(Integer.toString(aes.getInt("Total_Amount")));
            }
            
            String sql1 = "Select * from All_Orders order by OrderDate desc";
            String sql2 = "Select * from Expenses order by Date desc";
            PreparedStatement pst = con.prepareStatement(sql1);
            PreparedStatement sst = con.prepareStatement(sql2);
            ResultSet res = pst.executeQuery();
            ResultSet rs = sst.executeQuery();
            
            All_Transaction_Analysis();
            All_Order_Counting();
            
            All_Orders.setModel(new DefaultTableModel(null, new String[] {"Order ID","Customer ID","Dress ID","Order Date","Delivery Date","Rest Amount","Cost","Discount (%)","Order Type"}));
            All_Expenses.setModel(new DefaultTableModel(null, new String[] {"SI No", "Issue", "Cost Amount", "Short Description", "Date"}));
            
            while(res.next())
            {
                String tbData[] = {Integer.toString(res.getInt("OrderID")),
                                    res.getString("ID"),
                                    Integer.toString(res.getInt("DressID")),                                    
                                    res.getString("OrderDate"),
                                    res.getString("DeliveryDate"),
                                    Integer.toString(res.getInt("Rest")),
                                    Integer.toString(res.getInt("Total")),
                                    Integer.toString(res.getInt("Discount")),
                                    res.getString("OrderType")};
                DefaultTableModel tbModel = (DefaultTableModel) All_Orders.getModel();
                tbModel.addRow(tbData);
            }            
            while(rs.next())
            {
                String tbData[] = {Integer.toString(rs.getInt("SI_no")),
                                   rs.getString("Issue"),
                                   Integer.toString(rs.getInt("Cost_Ammount")),
                                   rs.getString("Description"),
                                   rs.getString("Date")};
                DefaultTableModel tbModel = (DefaultTableModel) All_Expenses.getModel();
                tbModel.addRow(tbData);
            }
            First_Date.setCalendar(null);
            Last_Date.setCalendar(null);
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void All_Transaction_Analysis(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            
            String sql1 = "select sum(Total) as Total_Amount from All_Orders";
            String sql2 = "select sum(Rest) as Total_Rest_Amount from All_Orders";
            String sql3 = "select sum(Cost_Ammount) as Cost_Amount from Expenses";
            
            PreparedStatement pst = con.prepareStatement(sql1);
            PreparedStatement sst = con.prepareStatement(sql2);
            PreparedStatement tst = con.prepareStatement(sql3);
            ResultSet rs = pst.executeQuery();
            ResultSet res = sst.executeQuery();
            ResultSet ress = tst.executeQuery();
            
            while(rs.next())
            {
                Total_Preparing_Cost.setText(Integer.toString(rs.getInt("Total_Amount")));
            }
            while(res.next())
            {
                Total_Rest.setText(Integer.toString(res.getInt("Total_Rest_Amount")));
            }
            Total_Paid.setText(Integer.toString(Integer.parseInt(Total_Preparing_Cost.getText()) - Integer.parseInt(Total_Rest.getText())));
            
            while(ress.next())
            {
                Total_Expense.setText(Integer.toString(ress.getInt("Cost_Amount")));
            }
            After_All.setText(Integer.toString(Integer.parseInt(Total_Paid.getText()) - Integer.parseInt(Total_Expense.getText())));
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    public void Specific_Transaction_Analysis(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql1, sql2, sql3;
            
            Date1 = sdf.format(First_Date.getDate());                
            Date2 = sdf.format(Last_Date.getDate());
            Date1 = Date1 + " 00:00:00.000";
            Date2 = Date2 + " 23:59:59.000";
            sql1 = "select sum(Total) as Total_Amount from All_Orders where OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"'";
            sql2 = "select sum(Rest) as Total_Rest_Amount from All_Orders where OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"'";
            sql3 = "select sum(Cost_Ammount) as Cost_Amount from Expenses where Date >= '"+Date1+"' and Date <= '"+Date2+"'";                
             
            PreparedStatement pst = con.prepareStatement(sql1);
            PreparedStatement sst = con.prepareStatement(sql2);
            PreparedStatement tst = con.prepareStatement(sql3);
            ResultSet rs = pst.executeQuery();
            ResultSet res = sst.executeQuery();
            ResultSet ress = tst.executeQuery();
            
            while(rs.next())
            {
                Total_Preparing_Cost.setText(Integer.toString(rs.getInt("Total_Amount")));
            }
            while(res.next())
            {
                Total_Rest.setText(Integer.toString(res.getInt("Total_Rest_Amount")));
            }
            Total_Paid.setText(Integer.toString(Integer.parseInt(Total_Preparing_Cost.getText()) - Integer.parseInt(Total_Rest.getText())));
            
            while(ress.next())
            {
                Total_Expense.setText(Integer.toString(ress.getInt("Cost_Amount")));
            }
            After_All.setText(Integer.toString(Integer.parseInt(Total_Paid.getText()) - Integer.parseInt(Total_Expense.getText())));
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    public void All_Order_Counting(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String type1 = "Pending", type2 = "Deliveried", type3 = "Cancelled";
            String sql1, sql2, sql3;
            
            sql1 = "Select count(OrderID) as Pending_Orders from All_Orders where OrderType = '"+type1+"'";
            sql2 = "Select count(OrderID) as Delivered_Orders from All_Orders where OrderType = '"+type2+"'";
            sql3 = "Select count(OrderID) as Cancelled_Orders from All_Orders where OrderType = '"+type3+"'";
            
            PreparedStatement pst = con.prepareStatement(sql1);
            PreparedStatement sst = con.prepareStatement(sql2);
            PreparedStatement tst = con.prepareStatement(sql3);
            ResultSet rs = pst.executeQuery();
            ResultSet res = sst.executeQuery();
            ResultSet ress = tst.executeQuery();
            
            while(rs.next())
            {
                Pending_Orders_no.setText(Integer.toString(rs.getInt("Pending_Orders")));
            }
            while(res.next())
            {
                Delivered_Orders_no.setText(Integer.toString(res.getInt("Delivered_Orders")));
            }
            while(ress.next())
            {
                Cancelled_Orders_no.setText(Integer.toString(ress.getInt("Cancelled_Orders")));
            }
            Total_Number_of_Orders.setText(Integer.toString(Integer.parseInt(Pending_Orders_no.getText()) + Integer.parseInt(Delivered_Orders_no.getText()) + Integer.parseInt(Cancelled_Orders_no.getText())));
            
        }catch(SQLException e){
        
            System.out.println(e);
            JOptionPane.showMessageDialog(null, e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    public void Specific_Order_Counting(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String type1 = "Pending", type2 = "Deliveried", type3 = "Cancelled";
            String sql1, sql2, sql3;
            
            Date1 = sdf.format(First_Date.getDate());                
            Date2 = sdf.format(Last_Date.getDate());
            Date1 = Date1 + " 00:00:00.000";
            Date2 = Date2 + " 23:59:59.000";
            sql1 = "Select count(OrderID) as Pending_Orders from All_Orders where OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"' and OrderType = '"+type1+"'";
            sql2 = "Select count(OrderID) as Delivered_Orders from All_Orders where OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"' and OrderType = '"+type2+"'";
            sql3 = "Select count(OrderID) as Cancelled_Orders from All_Orders where OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"' and OrderType = '"+type3+"'";                
            
            PreparedStatement pst = con.prepareStatement(sql1);
            PreparedStatement sst = con.prepareStatement(sql2);
            PreparedStatement tst = con.prepareStatement(sql3);
            ResultSet rs = pst.executeQuery();
            ResultSet res = sst.executeQuery();
            ResultSet ress = tst.executeQuery();
            
            while(rs.next())
            {
                Pending_Orders_no.setText(Integer.toString(rs.getInt("Pending_Orders")));
            }
            while(res.next())
            {
                Delivered_Orders_no.setText(Integer.toString(res.getInt("Delivered_Orders")));
            }
            while(ress.next())
            {
                Cancelled_Orders_no.setText(Integer.toString(ress.getInt("Cancelled_Orders")));
            }
            Total_Number_of_Orders.setText(Integer.toString(Integer.parseInt(Pending_Orders_no.getText()) + Integer.parseInt(Delivered_Orders_no.getText()) + Integer.parseInt(Cancelled_Orders_no.getText())));
            
        }catch(SQLException e){
        
            System.out.println(e);
            JOptionPane.showMessageDialog(null, e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        All_Orders = new javax.swing.JTable();
        MainMenu = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        All_View = new javax.swing.JButton();
        Search = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        Total_Number_of_Orders = new javax.swing.JTextField();
        First_Date = new com.toedter.calendar.JDateChooser();
        Last_Date = new com.toedter.calendar.JDateChooser();
        Pending_Orders_no = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        After_All = new javax.swing.JTextField();
        Total_Expense = new javax.swing.JTextField();
        Total_Paid = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        Total_Rest = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        All_Expenses = new javax.swing.JTable();
        Total_Preparing_Cost = new javax.swing.JTextField();
        Delivered_Orders_no = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        Cancelled_Orders_no = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        RootSelectionIcon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        All_Orders.setBackground(new java.awt.Color(249, 245, 242));
        All_Orders.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        All_Orders.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Order ID", "Customer ID", "Dress ID", "Order Date", "Delivery Date", "Rest Amount", "Cost", "Discount (%)", "Order Type"
            }
        ));
        All_Orders.setToolTipText("");
        All_Orders.setName(""); // NOI18N
        All_Orders.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                All_OrdersMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(All_Orders);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 1070, 170));

        MainMenu.setBackground(new java.awt.Color(249, 245, 242));
        MainMenu.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        MainMenu.setText("Main Menu");
        MainMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MainMenuActionPerformed(evt);
            }
        });
        getContentPane().add(MainMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 690, 140, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Logo_mini.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 20, 70, -1));

        All_View.setBackground(new java.awt.Color(249, 245, 242));
        All_View.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        All_View.setText("All View");
        All_View.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                All_ViewActionPerformed(evt);
            }
        });
        getContentPane().add(All_View, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 130, 110, 30));

        Search.setBackground(new java.awt.Color(249, 245, 242));
        Search.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Search.setText("Search");
        Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchActionPerformed(evt);
            }
        });
        getContentPane().add(Search, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 130, 110, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setText("From (1st date)");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 110, 90, 20));

        Total_Number_of_Orders.setEditable(false);
        Total_Number_of_Orders.setBackground(new java.awt.Color(249, 245, 242));
        Total_Number_of_Orders.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Total_Number_of_Orders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Total_Number_of_OrdersActionPerformed(evt);
            }
        });
        getContentPane().add(Total_Number_of_Orders, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 570, 180, 30));

        First_Date.setBackground(new java.awt.Color(249, 245, 242));
        First_Date.setDateFormatString("yyyy-MM-dd");
        First_Date.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        First_Date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                First_DateMouseClicked(evt);
            }
        });
        getContentPane().add(First_Date, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 130, 210, 30));

        Last_Date.setBackground(new java.awt.Color(249, 245, 242));
        Last_Date.setDateFormatString("yyyy-MM-dd");
        Last_Date.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Last_Date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Last_DateMouseClicked(evt);
            }
        });
        getContentPane().add(Last_Date, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 130, 210, 30));

        Pending_Orders_no.setEditable(false);
        Pending_Orders_no.setBackground(new java.awt.Color(249, 245, 242));
        Pending_Orders_no.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Pending_Orders_no.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Pending_Orders_noActionPerformed(evt);
            }
        });
        getContentPane().add(Pending_Orders_no, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 570, 180, 30));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel14.setText("Total Number of Orders");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 550, -1, 20));

        jLabel2.setFont(new java.awt.Font("Monotype Corsiva", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("All types of Expenses");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, 1070, 40));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel13.setText("To (Last date)");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 110, 90, 20));

        jLabel6.setFont(new java.awt.Font("Monotype Corsiva", 1, 24)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("All types Orders");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 1070, 40));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setText("Total Cancelled Orders");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 550, -1, 20));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel16.setText("Total Paid Amount (Taka)");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 610, -1, 20));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel17.setText("Total Delivered Orders");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 550, -1, 20));

        After_All.setEditable(false);
        After_All.setBackground(new java.awt.Color(249, 245, 242));
        After_All.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        After_All.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                After_AllActionPerformed(evt);
            }
        });
        getContentPane().add(After_All, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 630, 210, 30));

        Total_Expense.setEditable(false);
        Total_Expense.setBackground(new java.awt.Color(249, 245, 242));
        Total_Expense.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Total_Expense.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Total_ExpenseActionPerformed(evt);
            }
        });
        getContentPane().add(Total_Expense, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 630, 210, 30));

        Total_Paid.setEditable(false);
        Total_Paid.setBackground(new java.awt.Color(249, 245, 242));
        Total_Paid.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Total_Paid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Total_PaidActionPerformed(evt);
            }
        });
        getContentPane().add(Total_Paid, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 630, 210, 30));

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel21.setText("Total Rest Amount (Taka)");
        getContentPane().add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 610, -1, 20));

        Total_Rest.setEditable(false);
        Total_Rest.setBackground(new java.awt.Color(249, 245, 242));
        Total_Rest.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Total_Rest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Total_RestActionPerformed(evt);
            }
        });
        getContentPane().add(Total_Rest, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 630, 210, 30));

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel22.setText("Total Expense (Taka)");
        getContentPane().add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 610, -1, 20));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel23.setText("After All (Taka)");
        getContentPane().add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 610, -1, 20));

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel33.setText("Total Preparing Cost");
        getContentPane().add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 550, 120, 20));

        All_Expenses.setBackground(new java.awt.Color(249, 245, 242));
        All_Expenses.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "SI No", "Issue", "Cost Amount", "Short Description", "Date"
            }
        ));
        All_Expenses.setToolTipText("");
        All_Expenses.setName(""); // NOI18N
        All_Expenses.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                All_ExpensesMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(All_Expenses);

        getContentPane().add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 410, 1070, 130));

        Total_Preparing_Cost.setEditable(false);
        Total_Preparing_Cost.setBackground(new java.awt.Color(249, 245, 242));
        Total_Preparing_Cost.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(Total_Preparing_Cost, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 570, 180, 30));

        Delivered_Orders_no.setEditable(false);
        Delivered_Orders_no.setBackground(new java.awt.Color(249, 245, 242));
        Delivered_Orders_no.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Delivered_Orders_no.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Delivered_Orders_noActionPerformed(evt);
            }
        });
        getContentPane().add(Delivered_Orders_no, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 570, 180, 30));

        jLabel3.setFont(new java.awt.Font("Monotype Corsiva", 1, 24)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Transaction Analysis");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 490, 70));

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lebel_Bar.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 1110, 90));

        Cancelled_Orders_no.setEditable(false);
        Cancelled_Orders_no.setBackground(new java.awt.Color(249, 245, 242));
        Cancelled_Orders_no.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Cancelled_Orders_no.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cancelled_Orders_noActionPerformed(evt);
            }
        });
        getContentPane().add(Cancelled_Orders_no, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 570, 180, 30));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel18.setText("Total Pending Orders");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 550, -1, 20));

        RootSelectionIcon.setBackground(new java.awt.Color(255, 255, 255));
        RootSelectionIcon.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        RootSelectionIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/large.jpg"))); // NOI18N
        getContentPane().add(RootSelectionIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1110, 750));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MainMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MainMenuActionPerformed
        
        new Menu().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_MainMenuActionPerformed

    private void All_OrdersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_All_OrdersMouseClicked
        
    }//GEN-LAST:event_All_OrdersMouseClicked

    private void Pending_Orders_noActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Pending_Orders_noActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Pending_Orders_noActionPerformed

    private void Delivered_Orders_noActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Delivered_Orders_noActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Delivered_Orders_noActionPerformed

    private void Total_PaidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Total_PaidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Total_PaidActionPerformed

    private void Total_RestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Total_RestActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Total_RestActionPerformed

    private void All_ExpensesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_All_ExpensesMouseClicked
        int i = All_Expenses.getSelectedRow();
        TableModel model = All_Expenses.getModel();
    }//GEN-LAST:event_All_ExpensesMouseClicked

    private void SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchActionPerformed
                    
            try{
                Date1 = sdf.format(First_Date.getDate());                
                Date2 = sdf.format(Last_Date.getDate());
                Date1 = Date1 + " 00:00:00.000";
                Date2 = Date2 + " 23:59:59.000";
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql1 = "Select * from All_Orders where OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"' order by OrderDate desc";
                String sql2 = "Select * from Expenses where Date >= '"+Date1+"' and Date <= '"+Date2+"' order by Date desc";
                PreparedStatement pst = con.prepareStatement(sql1);
                PreparedStatement sst = con.prepareStatement(sql2);
                ResultSet res = pst.executeQuery();
                ResultSet rs = sst.executeQuery();
                
                Specific_Transaction_Analysis();
                Specific_Order_Counting();
                All_Orders.setModel(new DefaultTableModel(null, new String[] {"Order ID","Customer ID","Dress ID","Order Date","Delivery Date","Rest Amount","Cost","Discount (%)","Order Type"}));
                All_Expenses.setModel(new DefaultTableModel(null, new String[] {"SI No", "Issue", "Cost Amount", "Short Description", "Date"}));

                while(res.next())
                {
                    String tbData[] = {Integer.toString(res.getInt("OrderID")),
                                        res.getString("ID"),
                                        Integer.toString(res.getInt("DressID")),                                    
                                        res.getString("OrderDate"),
                                        res.getString("DeliveryDate"),
                                        Integer.toString(res.getInt("Rest")),
                                        Integer.toString(res.getInt("Total")),
                                        Integer.toString(res.getInt("Discount")),
                                        res.getString("OrderType")};
                    DefaultTableModel tbModel = (DefaultTableModel) All_Orders.getModel();
                    tbModel.addRow(tbData);
                }            
                while(rs.next())
                {
                    String tbData[] = {Integer.toString(rs.getInt("SI_no")),
                                       rs.getString("Issue"),
                                       Integer.toString(rs.getInt("Cost_Ammount")),
                                       rs.getString("Description"),
                                       rs.getString("Date")};
                    DefaultTableModel tbModel = (DefaultTableModel) All_Expenses.getModel();
                    tbModel.addRow(tbData);
                }
                
            }catch(SQLException e){
        
                System.out.println(e);
                JOptionPane.showMessageDialog(null, e); 
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Select the specific date !"); 
            }    
    }//GEN-LAST:event_SearchActionPerformed

    private void First_DateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_First_DateMouseClicked
        All_View();
    }//GEN-LAST:event_First_DateMouseClicked

    private void Last_DateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Last_DateMouseClicked
        All_View();
    }//GEN-LAST:event_Last_DateMouseClicked

    private void Cancelled_Orders_noActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Cancelled_Orders_noActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Cancelled_Orders_noActionPerformed

    private void Total_ExpenseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Total_ExpenseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Total_ExpenseActionPerformed

    private void After_AllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_After_AllActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_After_AllActionPerformed

    private void All_ViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_All_ViewActionPerformed
        All_View();
    }//GEN-LAST:event_All_ViewActionPerformed

    private void Total_Number_of_OrdersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Total_Number_of_OrdersActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Total_Number_of_OrdersActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Transaction().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField After_All;
    private javax.swing.JTable All_Expenses;
    private javax.swing.JTable All_Orders;
    private javax.swing.JButton All_View;
    private javax.swing.JTextField Cancelled_Orders_no;
    private javax.swing.JTextField Delivered_Orders_no;
    private com.toedter.calendar.JDateChooser First_Date;
    private com.toedter.calendar.JDateChooser Last_Date;
    private javax.swing.JButton MainMenu;
    private javax.swing.JTextField Pending_Orders_no;
    private javax.swing.JLabel RootSelectionIcon;
    private javax.swing.JButton Search;
    private javax.swing.JTextField Total_Expense;
    private javax.swing.JTextField Total_Number_of_Orders;
    private javax.swing.JTextField Total_Paid;
    private javax.swing.JTextField Total_Preparing_Cost;
    private javax.swing.JTextField Total_Rest;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    // End of variables declaration//GEN-END:variables

    private String getString(String fromInput) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void TicketGenerate(String text, String text0, String text1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private String getText(String format) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}