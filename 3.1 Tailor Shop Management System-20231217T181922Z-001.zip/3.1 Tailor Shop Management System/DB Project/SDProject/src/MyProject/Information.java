package MyProject;

import com.email.durgesh.Email;
import java.awt.Cursor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Information extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;

    String UserEmail = null;
    String EmailID = null;
    String EmailPassword = null;
    
    public Information() {
        initComponents();
        
        EmailID = SE.getText();
        EmailPassword = SEP.getText();
    }
    
    public void GetData()
    {
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql = "Select * from EmployeeDetails where ID like 'Admin%'";
            PreparedStatement pst = con.prepareStatement(sql);            
            ResultSet res = pst.executeQuery();
            
            while(res.next())
            {
                UserEmail = res.getString("Email");
            }
            
        }catch(SQLException e){

            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Employee_Info.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void Code_Send()
    {
        Random rand = new Random();
        int i;
        char[] text = new char[5];
        String Characters = "ACFHLMPSXYZ123456789";
        String Verification_Code = "";

        for(i=0; i<5; i++)
        {
            text[i] = Characters.charAt(rand.nextInt(Characters.length()));
        }
        
        for(i=0; i<text.length; i++)
        {
            Verification_Code += text[i];
        }

        try{
            Email email = new Email(EmailID, EmailPassword);

            email.setFrom(EmailID, "Tailor Shop Management System");

            email.setSubject("This email for verification.");

            email.setContent("<h2>The verification code is : </h2>" + Verification_Code, "text/html");

            email.addRecipient(UserEmail);

            email.send();

            new Verification("Information", Verification_Code).setVisible(true);
            this.setVisible(false);
        }

        catch(Exception e)
        {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Enter a valid Email address !");
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Developers = new javax.swing.JButton();
        Employee_Info = new javax.swing.JButton();
        Customer_Info = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Admin_Profile = new javax.swing.JButton();
        Back = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        Menu_icon = new javax.swing.JLabel();
        SE = new javax.swing.JLabel();
        SEP = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Main Menu");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Developers.setBackground(new java.awt.Color(249, 245, 242));
        Developers.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Developers.setText("Developers");
        Developers.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                DevelopersMouseMoved(evt);
            }
        });
        Developers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DevelopersActionPerformed(evt);
            }
        });
        getContentPane().add(Developers, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 350, 230, 50));

        Employee_Info.setBackground(new java.awt.Color(249, 245, 242));
        Employee_Info.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Employee_Info.setText("Employee Information");
        Employee_Info.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                Employee_InfoMouseMoved(evt);
            }
        });
        Employee_Info.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Employee_InfoActionPerformed(evt);
            }
        });
        getContentPane().add(Employee_Info, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 230, 230, 50));

        Customer_Info.setBackground(new java.awt.Color(249, 245, 242));
        Customer_Info.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Customer_Info.setText("Customer Information");
        Customer_Info.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                Customer_InfoMouseMoved(evt);
            }
        });
        Customer_Info.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Customer_InfoActionPerformed(evt);
            }
        });
        getContentPane().add(Customer_Info, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 170, 230, 50));

        jLabel2.setFont(new java.awt.Font("Monotype Corsiva", 1, 36)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Information Panel");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 760, 80));

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lebel_Bar.png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 760, 110));

        Admin_Profile.setBackground(new java.awt.Color(249, 245, 242));
        Admin_Profile.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Admin_Profile.setText("Admin Profile");
        Admin_Profile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Admin_ProfileActionPerformed(evt);
            }
        });
        getContentPane().add(Admin_Profile, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 290, 230, 50));

        Back.setBackground(new java.awt.Color(249, 245, 242));
        Back.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Back.setText("Main Menu");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });
        getContentPane().add(Back, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 410, 230, 50));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Logo_large.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 170, 260, 290));

        Menu_icon.setBackground(new java.awt.Color(255, 255, 255));
        Menu_icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Orders.jpg"))); // NOI18N
        getContentPane().add(Menu_icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, 540));

        SE.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        SE.setForeground(new java.awt.Color(255, 255, 255));
        SE.setText("190104131@aust.edu");
        getContentPane().add(SE, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 0, -1));

        SEP.setFont(new java.awt.Font("Tahoma", 0, 1)); // NOI18N
        SEP.setForeground(new java.awt.Color(255, 255, 255));
        SEP.setText("AhSaN131");
        getContentPane().add(SEP, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 0, 0));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Admin_ProfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Admin_ProfileActionPerformed
        
        GetData();
        Code_Send();
    }//GEN-LAST:event_Admin_ProfileActionPerformed

    private void Customer_InfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Customer_InfoActionPerformed
        
        new Customer_Info().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_Customer_InfoActionPerformed

    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        
        new Menu().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BackActionPerformed

    private void Customer_InfoMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Customer_InfoMouseMoved
        
        Cursor cursor;
        cursor = new Cursor(Cursor.HAND_CURSOR);
        Admin_Profile.setCursor(cursor);
        Customer_Info.setCursor(cursor);
        Back.setCursor(cursor);
    }//GEN-LAST:event_Customer_InfoMouseMoved

    private void DevelopersMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DevelopersMouseMoved
        // TODO add your handling code here:        
    }//GEN-LAST:event_DevelopersMouseMoved

    private void DevelopersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DevelopersActionPerformed
        // TODO add your handling code here:
        new Developers().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_DevelopersActionPerformed

    private void Employee_InfoMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Employee_InfoMouseMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_Employee_InfoMouseMoved

    private void Employee_InfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Employee_InfoActionPerformed
        // TODO add your handling code here:
        new Employee_Info().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_Employee_InfoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Information.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Information.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Information.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Information.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Information().setVisible(true);
            }
            
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Admin_Profile;
    private javax.swing.JButton Back;
    private javax.swing.JButton Customer_Info;
    private javax.swing.JButton Developers;
    private javax.swing.JButton Employee_Info;
    private javax.swing.JLabel Menu_icon;
    private javax.swing.JLabel SE;
    private javax.swing.JLabel SEP;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
