package MyProject;

import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author USER C
 */
public final class Order_Confirmation extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;
    
    String OrderType = "Temp";
    String Gender = null;
    int OrderID = 0;
    String DressID = null;
    int int_DressID = 0;
    String Cost = null;
    int Order_Num = 0;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    public Order_Confirmation() {
        
        initComponents();
        OrderID =0;
    }
    
    public Order_Confirmation(String Customer_ID,String Customer_Name,String Mobile_Number,String input_Gender,String Contact_Address) {
        
        initComponents();      
        OrderID =0;
        CustomerID.setText(Customer_ID);
        CustomerName.setText(Customer_Name);
        Gender = input_Gender;
        MobileNo.setText(Mobile_Number);
        Address.setText(Contact_Address);
        All_View();     
    }

    public void All_View(){
        
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            
            String sql1 = "Select All_Orders.OrderID, All_Orders.DressID, All_Orders.DeliveryDate, All_Orders.Rest, All_Orders.Total, All_Orders.Discount, Dress_Category.DressName from All_Orders inner join Dress_Category on All_Orders.DressID = Dress_Category.DressID where OrderType = '"+OrderType+"' order by OrderID asc";
            String sql2 = "Select count(OrderID) as Temp_Orders from All_Orders where OrderType = '"+OrderType+"'";
            String sql3 = "select sum(Total) as Total_Amount from All_Orders where OrderType = '"+OrderType+"'";
            String sql4 = "select sum(Rest) as Total_Rest_Amount from All_Orders where OrderType = '"+OrderType+"'";
            
            PreparedStatement pst = con.prepareStatement(sql1);
            PreparedStatement sst = con.prepareStatement(sql2);
            PreparedStatement tst = con.prepareStatement(sql3);
            PreparedStatement ust = con.prepareStatement(sql4);
            
            ResultSet res = pst.executeQuery();            
            ResultSet rs = sst.executeQuery();
            ResultSet rss = tst.executeQuery();
            ResultSet ress = ust.executeQuery();
            Order_Num = 0;
            CurrentOrders.setModel(new DefaultTableModel(null, new String[] {"Order ID","Dress ID","Dress Name","Delivery Date","Rest Amount","Cost","Discount (%)"}));
            while(res.next())
            {
                Order_Num ++;
                String tbData[] = {Integer.toString(res.getInt("OrderID")),
                                    Integer.toString(res.getInt("DressID")), 
                                    res.getString("DressName"),
                                    res.getString("DeliveryDate"),
                                    Integer.toString(res.getInt("Rest")),
                                    Integer.toString(res.getInt("Total")),
                                    Integer.toString(res.getInt("Discount"))};
                DefaultTableModel tbModel = (DefaultTableModel) CurrentOrders.getModel();
                tbModel.addRow(tbData);
            }
            if(Order_Num == 0)
            {
                new Menu().setVisible(true);
                this.setVisible(false);
            }            
            while(rs.next())
            {
                Total_Orders.setText(Integer.toString(rs.getInt("Temp_Orders")));
            }            
            while(rss.next())
            {
                Total_Cost.setText(Integer.toString(rss.getInt("Total_Amount")));
            }
            while(ress.next())
            {
                Rest_Amount.setText(Integer.toString(ress.getInt("Total_Rest_Amount")));
            }
            Payment_Amount.setText(Integer.toString(Integer.parseInt(Total_Cost.getText()) - Integer.parseInt(Rest_Amount.getText())));
            
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Customer_Info.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        CurrentOrders = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Total_Cost = new javax.swing.JTextField();
        Cancelled = new javax.swing.JButton();
        Add_More1 = new javax.swing.JButton();
        Add_More = new javax.swing.JButton();
        Address = new javax.swing.JTextField();
        CustomerName = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        Confirm = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        MobileNo = new javax.swing.JTextField();
        CustomerID = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        Payment_Amount = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        Rest_Amount = new javax.swing.JTextField();
        Delete = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        Total_Orders = new javax.swing.JTextField();
        Info_Icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        CurrentOrders.setBackground(new java.awt.Color(249, 245, 242));
        CurrentOrders.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        CurrentOrders.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Order ID", "Dress ID", "Dress Name", "Delivery Date", "Rest Amount", "Cost", "Discount (%)"
            }
        ));
        CurrentOrders.setToolTipText("");
        CurrentOrders.setName(""); // NOI18N
        CurrentOrders.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CurrentOrdersMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                CurrentOrdersMouseEntered(evt);
            }
        });
        jScrollPane2.setViewportView(CurrentOrders);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 910, 220));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Logo_small.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 20, 70, -1));

        jLabel2.setFont(new java.awt.Font("Monotype Corsiva", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Current Order List");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, 490, 70));

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lebel_Bar.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 950, 90));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Customer Name");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, -1, -1));

        Total_Cost.setEditable(false);
        Total_Cost.setBackground(new java.awt.Color(249, 245, 242));
        Total_Cost.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(Total_Cost, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 440, 190, 30));

        Cancelled.setBackground(new java.awt.Color(249, 245, 242));
        Cancelled.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Cancelled.setText("Cancelled All");
        Cancelled.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelledActionPerformed(evt);
            }
        });
        getContentPane().add(Cancelled, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, 150, 40));

        Add_More1.setBackground(new java.awt.Color(249, 245, 242));
        Add_More1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Add_More1.setText("Edit");
        Add_More1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_More1ActionPerformed(evt);
            }
        });
        getContentPane().add(Add_More1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 510, 150, 40));

        Add_More.setBackground(new java.awt.Color(249, 245, 242));
        Add_More.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Add_More.setText("Add More");
        Add_More.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_MoreActionPerformed(evt);
            }
        });
        getContentPane().add(Add_More, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 510, 150, 40));

        Address.setEditable(false);
        Address.setBackground(new java.awt.Color(249, 245, 242));
        Address.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(Address, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 130, 240, 30));

        CustomerName.setEditable(false);
        CustomerName.setBackground(new java.awt.Color(249, 245, 242));
        CustomerName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(CustomerName, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 130, 200, 30));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Total Cost (Taka)");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 420, 130, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("Contact Address");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 110, -1, -1));

        Confirm.setBackground(new java.awt.Color(249, 245, 242));
        Confirm.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Confirm.setText("Confirm");
        Confirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmActionPerformed(evt);
            }
        });
        getContentPane().add(Confirm, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 510, 150, 40));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel14.setText("Mobile Number");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 110, 90, 20));

        MobileNo.setEditable(false);
        MobileNo.setBackground(new java.awt.Color(249, 245, 242));
        MobileNo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        MobileNo.setText("01");
        MobileNo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MobileNoMouseClicked(evt);
            }
        });
        MobileNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MobileNoActionPerformed(evt);
            }
        });
        getContentPane().add(MobileNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 130, 170, 30));

        CustomerID.setEditable(false);
        CustomerID.setBackground(new java.awt.Color(249, 245, 242));
        CustomerID.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        CustomerID.setText("CI_100");
        CustomerID.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CustomerIDMouseClicked(evt);
            }
        });
        CustomerID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CustomerIDActionPerformed(evt);
            }
        });
        getContentPane().add(CustomerID, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 120, 30));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setText("Customer ID");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, 20));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setText("Payment Amount (Taka)");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 420, 180, -1));

        Payment_Amount.setEditable(false);
        Payment_Amount.setBackground(new java.awt.Color(249, 245, 242));
        Payment_Amount.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(Payment_Amount, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 440, 190, 30));

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel22.setText("Rest Amount (Taka)");
        getContentPane().add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 420, 130, -1));

        Rest_Amount.setEditable(false);
        Rest_Amount.setBackground(new java.awt.Color(249, 245, 242));
        Rest_Amount.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(Rest_Amount, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 440, 190, 30));

        Delete.setBackground(new java.awt.Color(249, 245, 242));
        Delete.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Delete.setText("Delete");
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });
        getContentPane().add(Delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 510, 150, 40));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel23.setText("Total Orders");
        getContentPane().add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, 130, -1));

        Total_Orders.setEditable(false);
        Total_Orders.setBackground(new java.awt.Color(249, 245, 242));
        Total_Orders.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(Total_Orders, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 440, 160, 30));

        Info_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/large.jpg"))); // NOI18N
        getContentPane().add(Info_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 580));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CurrentOrdersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CurrentOrdersMouseClicked
        int i = CurrentOrders.getSelectedRow();
        TableModel model = CurrentOrders.getModel();
        
        OrderID = Integer.parseInt((String) model.getValueAt(i, 0));
        DressID = (String) model.getValueAt(i, 1);
    }//GEN-LAST:event_CurrentOrdersMouseClicked
    
    
    private void CancelledActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelledActionPerformed
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String OrderType = "Temp";
            String sql = "select * from All_Orders where OrderType = '"+OrderType+"'";
            
            PreparedStatement tst = con.prepareStatement(sql);
            
            ResultSet rss = tst.executeQuery();
            
            while(rss.next())
            {                
                String sql1 = "delete from All_Orders where OrderID = '"+rss.getInt("OrderID")+"' and OrderType = '"+OrderType+"'";
                String sql2 = "delete from Measurements where OrderID = '"+rss.getInt("OrderID")+"'";

                PreparedStatement pst = con.prepareStatement(sql1);
                PreparedStatement sst = con.prepareStatement(sql2);
                sst.executeUpdate();
                pst.executeUpdate();                
            }
            
            new Menu().setVisible(true);
            this.setVisible(false);
            
        }catch(SQLException e){

            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Dress_Category.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }//GEN-LAST:event_CancelledActionPerformed

    private void Add_MoreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_MoreActionPerformed
        try {
            new Add_More(CustomerID.getText(),CustomerName.getText(),MobileNo.getText(),Gender,Address.getText()).setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Order_Confirmation.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.setVisible(false);
    }//GEN-LAST:event_Add_MoreActionPerformed

    private void ConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmActionPerformed
        int result = JOptionPane.showConfirmDialog(this,"Have you received the advance of the cost ?","Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
                
        if(result == JOptionPane.YES_OPTION){
            
        try{
            Date CurrentDate = new Date();
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String Current_Type = "Pending";
            String sql = "update All_Orders set OrderDate = '"+sdf.format(CurrentDate)+"', OrderType = '"+Current_Type+"' where OrderType = '"+OrderType+"'";

            PreparedStatement pst = con.prepareStatement(sql);

            pst.executeUpdate();

            JOptionPane.showMessageDialog(null, "The orders have been added !");
            
            new Menu().setVisible(true);
            this.setVisible(false);
            
        }catch(SQLException e){
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Dress_Category.class.getName()).log(Level.SEVERE, null, ex);
        }    

            All_View();              
        }        
    }//GEN-LAST:event_ConfirmActionPerformed

    private void MobileNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MobileNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MobileNoActionPerformed

    private void MobileNoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MobileNoMouseClicked
        
    }//GEN-LAST:event_MobileNoMouseClicked

    private void CustomerIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CustomerIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CustomerIDActionPerformed

    private void CustomerIDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustomerIDMouseClicked
        
    }//GEN-LAST:event_CustomerIDMouseClicked

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
        if(OrderID != 0){
         
        int result = JOptionPane.showConfirmDialog(this,"Do you want to delete ?","Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
                
        if(result == JOptionPane.YES_OPTION){
            
            try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql1 = "delete from All_Orders where OrderID = '"+OrderID+"' and OrderType = '"+OrderType+"'";
            String sql2 = "delete from Measurements where OrderID = '"+OrderID+"'";
            
            PreparedStatement pst = con.prepareStatement(sql1);
            PreparedStatement sst = con.prepareStatement(sql2);
            
            sst.executeUpdate();            
            pst.executeUpdate();
            OrderID =0;
            
            JOptionPane.showMessageDialog(null, "The selected info has been deleted !"); 
            
            }catch(SQLException e){

                System.out.println(e);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Dress_Category.class.getName()).log(Level.SEVERE, null, ex);
            }    

            All_View();              
        }
      }else{
            JOptionPane.showMessageDialog(null, "Select an order !"); 
      }
        
    }//GEN-LAST:event_DeleteActionPerformed

    private void CurrentOrdersMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CurrentOrdersMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_CurrentOrdersMouseEntered

    private void Add_More1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_More1ActionPerformed
        if(OrderID != 0)
        {            
            new Add_More(CustomerID.getText(), OrderID, DressID).setVisible(true);
            this.setVisible(false);
        }else{
            JOptionPane.showMessageDialog(null, "Select an order !"); 
        }
    }//GEN-LAST:event_Add_More1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Order_Confirmation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Order_Confirmation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Order_Confirmation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Order_Confirmation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Order_Confirmation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add_More;
    private javax.swing.JButton Add_More1;
    private javax.swing.JTextField Address;
    private javax.swing.JButton Cancelled;
    private javax.swing.JButton Confirm;
    private javax.swing.JTable CurrentOrders;
    private javax.swing.JTextField CustomerID;
    private javax.swing.JTextField CustomerName;
    private javax.swing.JButton Delete;
    private javax.swing.JLabel Info_Icon;
    private javax.swing.JTextField MobileNo;
    private javax.swing.JTextField Payment_Amount;
    private javax.swing.JTextField Rest_Amount;
    private javax.swing.JTextField Total_Cost;
    private javax.swing.JTextField Total_Orders;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables

    private String getString(String fromInput) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void TicketGenerate(String text, String text0, String text1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private String getText(String format) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}