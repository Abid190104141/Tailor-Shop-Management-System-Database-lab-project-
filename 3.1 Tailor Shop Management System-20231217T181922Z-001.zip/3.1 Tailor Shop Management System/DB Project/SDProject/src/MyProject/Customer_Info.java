package MyProject;

import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public final class Customer_Info extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;
    
    int Last_SI = 0;
    int Paid_Amount = 0;
    int Rest_Amount = 0;
    int Preparing_Cost = 0;
    int Cost_Amount = 0;
    int Pending_Orders = 0;
    int Deliveried_Orders = 0;
    int Cancelled_Orders = 0;
            
    
    public Customer_Info() {
        
        initComponents();        
        All_View();
    }
    
    public void All_View(){
        
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql = "Select * from Information where ID like 'CI_%'";
            PreparedStatement sst = con.prepareStatement(sql);
            
            ResultSet res = sst.executeQuery();
            CustomerInfo.setModel(new DefaultTableModel(null, new String[] {"Customer ID","Customer Name","Gender","Mobile Number","Address"}));
            
            while(res.next())
            {
                String tbData[] = {res.getString("ID"),
                                    res.getString("Name"),
                                    res.getString("Gender"),
                                    res.getString("MobileNumber"),
                                    res.getString("Address")};
                DefaultTableModel tbModel = (DefaultTableModel) CustomerInfo.getModel();
                tbModel.addRow(tbData);
            }
            Reset();
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Customer_Info.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void Calculation(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String type1 = "Pending", type2 = "Deliveried", type3 = "Cancelled";
            
            String sql1 = "select sum(Total) as Total_Amount from All_Orders where ID = '"+CustomerID.getText()+"'";
            String sql2 = "select sum(Rest) as Total_Rest_Amount from All_Orders where ID = '"+CustomerID.getText()+"'";
            String sql3 = "Select count(OrderID) as Pending_Orders from All_Orders where OrderType = '"+type1+"' and ID = '"+CustomerID.getText()+"'";
            String sql4 = "Select count(OrderID) as Delivered_Orders from All_Orders where OrderType = '"+type2+"' and ID = '"+CustomerID.getText()+"'";
            String sql5 = "Select count(OrderID) as Cancelled_Orders from All_Orders where OrderType = '"+type3+"' and ID = '"+CustomerID.getText()+"'";
            
            PreparedStatement ost = con.prepareStatement(sql1);
            PreparedStatement pst = con.prepareStatement(sql2);
            PreparedStatement sst = con.prepareStatement(sql3);
            PreparedStatement tst = con.prepareStatement(sql4);
            PreparedStatement ust = con.prepareStatement(sql5);
            
            ResultSet rs = ost.executeQuery();
            ResultSet rss = pst.executeQuery();
            ResultSet res = sst.executeQuery();
            ResultSet ress = tst.executeQuery();
            ResultSet reess = ust.executeQuery();            
            
            while(rs.next())
            {
                Total_Preparing_Cost.setText(Integer.toString(rs.getInt("Total_Amount")));
            }
            while(rss.next())
            {
                Total_Rest.setText(Integer.toString(rss.getInt("Total_Rest_Amount")));
            }
            Total_Paid.setText(Integer.toString(Integer.parseInt(Total_Preparing_Cost.getText()) - Integer.parseInt(Total_Rest.getText())));
            while(res.next())
            {
                Pending.setText(Integer.toString(res.getInt("Pending_Orders")));
            }
            while(ress.next())
            {
                Delivered.setText(Integer.toString(ress.getInt("Delivered_Orders")));
            }
            while(reess.next())
            {
                Cancelled.setText(Integer.toString(reess.getInt("Cancelled_Orders")));
            }
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }
    
    public void Reset(){
        CustomerID.setText("CI_100");
        MobileNo.setText("01");
        CustomerName.setText(null);
        MobileNo_copy.setText("01");
        Address.setText(null);
        Gender.setSelectedIndex(0);
        Pending.setText(null);
        Delivered.setText(null);
        Cancelled.setText(null);
        Total_Preparing_Cost.setText(null);
        Total_Paid.setText(null);
        Total_Rest.setText(null);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        CustomerInfo = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Gender = new javax.swing.JComboBox<>();
        Address = new javax.swing.JTextField();
        CustomerName = new javax.swing.JTextField();
        MobileNo_copy = new javax.swing.JTextField();
        MainMenu = new javax.swing.JButton();
        Details = new javax.swing.JButton();
        Add = new javax.swing.JButton();
        Update = new javax.swing.JButton();
        CustomerID = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        Seach_using_CustomerID = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        MobileNo = new javax.swing.JTextField();
        Seach_using_MobileNo = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        Pending = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        Delivered = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        Cancelled = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        Total_Preparing_Cost = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        Total_Paid = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        Total_Rest = new javax.swing.JTextField();
        All_View = new javax.swing.JButton();
        Info_Icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        CustomerInfo.setBackground(new java.awt.Color(249, 245, 242));
        CustomerInfo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Customer ID", "Customer Name", "Gender", "Mobile Number", "Address"
            }
        ));
        CustomerInfo.setToolTipText("");
        CustomerInfo.setName(""); // NOI18N
        CustomerInfo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CustomerInfoMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(CustomerInfo);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 640, 230));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Logo_small.png"))); // NOI18N
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 20, 70, -1));

        jLabel2.setFont(new java.awt.Font("Monotype Corsiva", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Customer Information");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 20, 380, 60));

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lebel_Small.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 720, 90));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("Customer Name");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 430, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Contact Address");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 490, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("Mobile Number");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 430, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Gender");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 490, -1, -1));

        Gender.setBackground(new java.awt.Color(249, 245, 242));
        Gender.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<<Select>>", "Male", "Female" }));
        getContentPane().add(Gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 510, 310, 31));

        Address.setBackground(new java.awt.Color(249, 245, 242));
        Address.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Address.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddressActionPerformed(evt);
            }
        });
        getContentPane().add(Address, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 510, 310, 30));

        CustomerName.setBackground(new java.awt.Color(249, 245, 242));
        CustomerName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        CustomerName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CustomerNameActionPerformed(evt);
            }
        });
        getContentPane().add(CustomerName, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 450, 310, 30));

        MobileNo_copy.setBackground(new java.awt.Color(249, 245, 242));
        MobileNo_copy.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(MobileNo_copy, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 450, 310, 30));

        MainMenu.setBackground(new java.awt.Color(249, 245, 242));
        MainMenu.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        MainMenu.setText("Back");
        MainMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MainMenuActionPerformed(evt);
            }
        });
        getContentPane().add(MainMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 630, 130, 40));

        Details.setBackground(new java.awt.Color(249, 245, 242));
        Details.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Details.setText("Details");
        Details.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DetailsActionPerformed(evt);
            }
        });
        getContentPane().add(Details, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 630, 130, 40));

        Add.setBackground(new java.awt.Color(249, 245, 242));
        Add.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Add.setText("Add a new");
        Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddActionPerformed(evt);
            }
        });
        getContentPane().add(Add, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 630, 130, 40));

        Update.setBackground(new java.awt.Color(249, 245, 242));
        Update.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Update.setText("Update");
        Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateActionPerformed(evt);
            }
        });
        getContentPane().add(Update, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 630, 130, 40));

        CustomerID.setBackground(new java.awt.Color(249, 245, 242));
        CustomerID.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        CustomerID.setText("CI_100");
        CustomerID.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CustomerIDMouseClicked(evt);
            }
        });
        getContentPane().add(CustomerID, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 130, 110, 30));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setText("Customer ID");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 110, -1, 20));

        Seach_using_CustomerID.setBackground(new java.awt.Color(249, 245, 242));
        Seach_using_CustomerID.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Seach_using_CustomerID.setText("Search");
        Seach_using_CustomerID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Seach_using_CustomerIDActionPerformed(evt);
            }
        });
        getContentPane().add(Seach_using_CustomerID, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 130, 80, 30));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel14.setText("Mobile Number");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 110, 90, 20));

        MobileNo.setBackground(new java.awt.Color(249, 245, 242));
        MobileNo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        MobileNo.setText("01");
        MobileNo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MobileNoMouseClicked(evt);
            }
        });
        MobileNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MobileNoActionPerformed(evt);
            }
        });
        getContentPane().add(MobileNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 130, 150, 30));

        Seach_using_MobileNo.setBackground(new java.awt.Color(249, 245, 242));
        Seach_using_MobileNo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Seach_using_MobileNo.setText("Search");
        Seach_using_MobileNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Seach_using_MobileNoActionPerformed(evt);
            }
        });
        getContentPane().add(Seach_using_MobileNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 130, 80, 30));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel16.setText("Pending");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 550, -1, 20));

        Pending.setEditable(false);
        Pending.setBackground(new java.awt.Color(249, 245, 242));
        Pending.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Pending.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PendingActionPerformed(evt);
            }
        });
        getContentPane().add(Pending, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 570, 90, 30));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel17.setText("Delivered");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 550, -1, 20));

        Delivered.setEditable(false);
        Delivered.setBackground(new java.awt.Color(249, 245, 242));
        Delivered.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Delivered.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeliveredActionPerformed(evt);
            }
        });
        getContentPane().add(Delivered, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 570, 90, 30));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel18.setText("Cancelled");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 550, -1, 20));

        Cancelled.setEditable(false);
        Cancelled.setBackground(new java.awt.Color(249, 245, 242));
        Cancelled.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Cancelled.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelledActionPerformed(evt);
            }
        });
        getContentPane().add(Cancelled, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 570, 90, 30));

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel33.setText("Total Order (Taka)");
        getContentPane().add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 550, 120, 20));

        Total_Preparing_Cost.setEditable(false);
        Total_Preparing_Cost.setBackground(new java.awt.Color(249, 245, 242));
        Total_Preparing_Cost.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(Total_Preparing_Cost, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 570, 90, 30));

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel19.setText("Total Paid (Taka)");
        getContentPane().add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 550, -1, 20));

        Total_Paid.setEditable(false);
        Total_Paid.setBackground(new java.awt.Color(249, 245, 242));
        Total_Paid.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Total_Paid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Total_PaidActionPerformed(evt);
            }
        });
        getContentPane().add(Total_Paid, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 570, 90, 30));

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel21.setText("Total Rest (Taka)");
        getContentPane().add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 550, -1, 20));

        Total_Rest.setEditable(false);
        Total_Rest.setBackground(new java.awt.Color(249, 245, 242));
        Total_Rest.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Total_Rest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Total_RestActionPerformed(evt);
            }
        });
        getContentPane().add(Total_Rest, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 570, 90, 30));

        All_View.setBackground(new java.awt.Color(249, 245, 242));
        All_View.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        All_View.setText("All View");
        All_View.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                All_ViewActionPerformed(evt);
            }
        });
        getContentPane().add(All_View, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 120, 30));

        Info_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Customer_Info.jpg"))); // NOI18N
        getContentPane().add(Info_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 720, 750));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CustomerInfoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustomerInfoMouseClicked
        int i = CustomerInfo.getSelectedRow();
        TableModel model = CustomerInfo.getModel();
        
        CustomerID.setText((String) model.getValueAt(i, 0));
        CustomerName.setText((String) model.getValueAt(i, 1));
        String temp = (String) model.getValueAt(i, 2);
        if(temp.equals("Male"))
        {
            Gender.setSelectedIndex(1);
        }else{
            Gender.setSelectedIndex(2);        
        }
        MobileNo.setText((String) model.getValueAt(i, 3));
        MobileNo_copy.setText((String) model.getValueAt(i, 3));
        Address.setText((String) model.getValueAt(i, 4));
        Calculation();        
    }//GEN-LAST:event_CustomerInfoMouseClicked
    
    
    private void MainMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MainMenuActionPerformed
        
        new Information().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_MainMenuActionPerformed

    private void UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateActionPerformed
        //Update in database
        if(CustomerName.getText().isEmpty() || Gender.getSelectedItem().equals("<<Select>>") || MobileNo_copy.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Enter the all the Information !");
        }
        else if(Long.parseLong(MobileNo_copy.getText()) < 1100000000)
        {
            JOptionPane.showMessageDialog(null, "Enter the Mobile Number correctly !");
        }
        else
        {
           try{
                long validity = 0;
                validity = Long.parseLong(MobileNo_copy.getText());
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);

                String sql = "update Information set Name = '"+CustomerName.getText()+"', Gender = '"+(String) Gender.getSelectedItem()+"', MobileNumber = '"+MobileNo_copy.getText()+"', Address = '"+Address.getText()+"' where ID = '"+CustomerID.getText()+"'";

                PreparedStatement pst = con.prepareStatement(sql);

                pst.executeUpdate();

                JOptionPane.showMessageDialog(null, "The updated info has been added !"); 
            
            }catch(SQLException e){

                System.out.println(e);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Enter a valid Mobile Number !");
            }   

            All_View(); 
        }
    }//GEN-LAST:event_UpdateActionPerformed

    private void AddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AddressActionPerformed

    private void CustomerNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CustomerNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CustomerNameActionPerformed

    private void CustomerIDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustomerIDMouseClicked
        // TODO add your handling code here:
        All_View();
        Reset();
    }//GEN-LAST:event_CustomerIDMouseClicked

    private void MobileNoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MobileNoMouseClicked
        // TODO add your handling code here:
        All_View();
        Reset();
    }//GEN-LAST:event_MobileNoMouseClicked

    private void MobileNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MobileNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MobileNoActionPerformed

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        //Add to database
        if(CustomerName.getText().isEmpty() || Gender.getSelectedItem().equals("<<Select>>") || MobileNo_copy.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Enter the all the Information !");
        }
        else if(Long.parseLong(MobileNo_copy.getText()) < 1100000000)
        {
            JOptionPane.showMessageDialog(null, "Enter the Mobile Number correctly !");
        }
        else
        {
            try{
                long validity = 0;
                validity = Long.parseLong(MobileNo_copy.getText());
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql1 = "Select count(ID) as CustomerID from Information where ID like 'CI_%'";
            
                PreparedStatement pst = con.prepareStatement(sql1);
                ResultSet rs = pst.executeQuery();
            
                while(rs.next())
                {
                    Last_SI = rs.getInt("CustomerID");
                }
                String ID;
                if(Last_SI == 0)
                {
                    ID = "CI_" + Integer.toString(10001);
                }
                else{
                    ID = "CI_" + Integer.toString(10001+Last_SI);
                }
                String sql2 = "insert into Information(ID, Name, Gender, MobileNumber, Address) values ('"+ID+"','"+CustomerName.getText()+"','"+(String) Gender.getSelectedItem()+"','"+MobileNo_copy.getText()+"','"+Address.getText()+"')";

                PreparedStatement qst = con.prepareStatement(sql2);

                qst.executeUpdate();

                JOptionPane.showMessageDialog(null, "The inserted info has been added !"); 

            }catch(SQLException e){

                System.out.println(e);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Enter a valid Mobile Number !");
            }

            All_View();
        }
    }//GEN-LAST:event_AddActionPerformed

    private void Seach_using_CustomerIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Seach_using_CustomerIDActionPerformed
        if(CustomerID.getText().trim().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Enter the customer ID !"); 
        }else{
        
            try{
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql = "Select * from Information where ID = '"+CustomerID.getText()+"' and ID like 'CI_%'";
                PreparedStatement pst = con.prepareStatement(sql);            
                ResultSet res = pst.executeQuery();
                CustomerInfo.setModel(new DefaultTableModel(null, new String[] {"Customer ID","Customer Name","Gender","Mobile Number","Address"}));

                while(res.next())
                {
                    CustomerName.setText(res.getString("Name"));
                    if(res.getString("Gender").equals("Male"))
                    {
                        Gender.setSelectedIndex(1);
                    }else{
                        Gender.setSelectedIndex(2);        
                    }
                    MobileNo_copy.setText(res.getString("MobileNumber"));
                    Address.setText(res.getString("Address"));
                    
                    String tbData[] = {res.getString("ID"),
                                        res.getString("Name"),
                                        res.getString("Gender"),
                                        res.getString("MobileNumber"),
                                        res.getString("Address")};
                    DefaultTableModel tbModel = (DefaultTableModel) CustomerInfo.getModel();
                    tbModel.addRow(tbData);
                }
                Calculation();
                CustomerName.setText(null);
                Gender.setSelectedIndex(0);
                MobileNo_copy.setText(null);
                Address.setText(null);

            }catch(SQLException e){

                System.out.println(e);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Customer_Info.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_Seach_using_CustomerIDActionPerformed

    private void Seach_using_MobileNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Seach_using_MobileNoActionPerformed
        if(MobileNo.getText().trim().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Enter the mobile number !"); 
        }else{
            try{
                long check = Long.parseLong(MobileNo.getText());
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql = "Select * from Information where MobileNumber = '"+MobileNo.getText()+"' and ID like 'CI_%'";
                PreparedStatement pst = con.prepareStatement(sql);            
                ResultSet res = pst.executeQuery();
                CustomerInfo.setModel(new DefaultTableModel(null, new String[] {"Customer ID","Customer Name","Gender","Mobile Number","Address"}));

                while(res.next())
                {   
                    CustomerName.setText(res.getString("Name"));
                    if(res.getString("Gender").equals("Male"))
                    {
                        Gender.setSelectedIndex(1);
                    }else{
                        Gender.setSelectedIndex(2);        
                    }
                    MobileNo_copy.setText(res.getString("MobileNumber"));
                    Address.setText(res.getString("Address"));
                    
                    String tbData[] = {res.getString("ID"),
                                        res.getString("Name"),
                                        res.getString("Gender"),
                                        res.getString("MobileNumber"),
                                        res.getString("Address")};
                    DefaultTableModel tbModel = (DefaultTableModel) CustomerInfo.getModel();
                    tbModel.addRow(tbData);
                }
                Calculation();
                
            }catch(SQLException e){

                System.out.println(e);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Enter the valid mobile number !");
            }
        }
    }//GEN-LAST:event_Seach_using_MobileNoActionPerformed

    private void PendingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PendingActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PendingActionPerformed

    private void DeliveredActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeliveredActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DeliveredActionPerformed

    private void CancelledActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelledActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CancelledActionPerformed

    private void Total_PaidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Total_PaidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Total_PaidActionPerformed

    private void Total_RestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Total_RestActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Total_RestActionPerformed

    private void DetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DetailsActionPerformed
        if(CustomerID.getText().isEmpty() || CustomerName.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Select a customer !");
        }
        else{
            new Customer_Details(CustomerID.getText(), CustomerName.getText()).setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_DetailsActionPerformed

    private void All_ViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_All_ViewActionPerformed
        All_View();
        Reset();
    }//GEN-LAST:event_All_ViewActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Customer_Info().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JTextField Address;
    private javax.swing.JButton All_View;
    private javax.swing.JTextField Cancelled;
    private javax.swing.JTextField CustomerID;
    private javax.swing.JTable CustomerInfo;
    private javax.swing.JTextField CustomerName;
    private javax.swing.JTextField Delivered;
    private javax.swing.JButton Details;
    private javax.swing.JComboBox<String> Gender;
    private javax.swing.JLabel Info_Icon;
    private javax.swing.JButton MainMenu;
    private javax.swing.JTextField MobileNo;
    private javax.swing.JTextField MobileNo_copy;
    private javax.swing.JTextField Pending;
    private javax.swing.JButton Seach_using_CustomerID;
    private javax.swing.JButton Seach_using_MobileNo;
    private javax.swing.JTextField Total_Paid;
    private javax.swing.JTextField Total_Preparing_Cost;
    private javax.swing.JTextField Total_Rest;
    private javax.swing.JButton Update;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables

    private String getString(String fromInput) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void TicketGenerate(String text, String text0, String text1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private String getText(String format) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}