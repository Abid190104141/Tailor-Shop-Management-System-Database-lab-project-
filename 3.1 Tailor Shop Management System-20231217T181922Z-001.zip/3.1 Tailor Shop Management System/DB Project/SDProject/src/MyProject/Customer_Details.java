package MyProject;

import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public final class Customer_Details extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;

    String Order_Date = null;
    String Delivery_Date = null;
    String Date1 = null;
    String Date2 = null;
    String OrderType = null;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
    public Customer_Details(){
        
        initComponents();
        Date date = new Date();  
    }
    
    public Customer_Details(String CustomerID, String CustomerName){
        
        initComponents();
        Date date = new Date();
        this.CustomerID.setText(CustomerID);
        this.CustomerName.setText(CustomerName);
        All_View();        
        Customer_Info();        
    }
    
    public void All_View(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            OrderType = "Pending";
            String sql1 = "Select * from All_Orders where ID = '"+CustomerID.getText()+"' and OrderType = '"+OrderType+"' order by OrderDate asc";
            OrderType = "Deliveried";
            String sql2 = "Select * from All_Orders where ID = '"+CustomerID.getText()+"' and OrderType = '"+OrderType+"' order by DeliveryDate desc";
            OrderType = "Cancelled";
            String sql3 = "Select * from All_Orders where ID = '"+CustomerID.getText()+"' and OrderType = '"+OrderType+"' order by DeliveryDate desc";
            
            PreparedStatement pst = con.prepareStatement(sql1);
            PreparedStatement qst = con.prepareStatement(sql2);
            PreparedStatement rst = con.prepareStatement(sql3);
            
            ResultSet rs = pst.executeQuery();  
            ResultSet res = qst.executeQuery();  
            ResultSet ress = rst.executeQuery();  
            
            All_Transaction_Analysis();
            All_Order_Counting();
            First_Date.setCalendar(null);
            Last_Date.setCalendar(null);
            PendingOrders.setModel(new DefaultTableModel(null, new String[] {"Order ID","Customer ID","Dress ID","Order Date","Delivery Date","Rest Amount","Cost","Discount (%)"}));
            DeliveredOrders.setModel(new DefaultTableModel(null, new String[] {"Order ID","Customer ID","Dress ID","Order Date","Delivery Date","Preparing Cost","Discount (%)"}));
            CancelledOrders.setModel(new DefaultTableModel(null, new String[] {"Order ID","Customer ID","Dress ID","Order Date","Cancellation Date","Penalty Rate"}));
            while(rs.next())
            {
                String tbData[] = {Integer.toString(rs.getInt("OrderID")),
                                   rs.getString("ID"),
                                   Integer.toString(rs.getInt("DressID")),                                    
                                   rs.getString("OrderDate"),
                                   rs.getString("DeliveryDate"),
                                   Integer.toString(rs.getInt("Rest")),
                                   Integer.toString(rs.getInt("Total")),
                                   Integer.toString(rs.getInt("Discount"))};
                DefaultTableModel tbModel = (DefaultTableModel) PendingOrders.getModel();
                tbModel.addRow(tbData);
            }
            while(res.next())
            {
                String tbData[] = {Integer.toString(res.getInt("OrderID")),
                                   res.getString("ID"),
                                   Integer.toString(res.getInt("DressID")),                                    
                                   res.getString("OrderDate"),
                                   res.getString("DeliveryDate"),
                                   Integer.toString(res.getInt("Total")),
                                   Integer.toString(res.getInt("Discount"))};
                DefaultTableModel tbModel = (DefaultTableModel) DeliveredOrders.getModel();
                tbModel.addRow(tbData);
            }
            while(ress.next())
            {
                String tbData[] = {Integer.toString(ress.getInt("OrderID")),
                                   ress.getString("ID"),
                                   Integer.toString(ress.getInt("DressID")),                                    
                                   ress.getString("OrderDate"),
                                   ress.getString("DeliveryDate"),
                                   Integer.toString(ress.getInt("Total"))};
                DefaultTableModel tbModel = (DefaultTableModel) CancelledOrders.getModel();
                tbModel.addRow(tbData);
            }
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Customer_Info.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void Customer_Info(){
        try{
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql = "Select * from Information where ID = '"+CustomerID.getText()+"' and ID like 'CI_%'";
                PreparedStatement pst = con.prepareStatement(sql);            
                ResultSet res = pst.executeQuery();
                
                while(res.next())
                {
                    MobileNo.setText(res.getString("MobileNumber"));
                    Gender.setText(res.getString("Gender"));
                    Address.setText(res.getString("Address"));
                }
            }catch(SQLException e){

                System.out.println(e);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Customer_Info.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    public void All_Transaction_Analysis(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            
            String sql1 = "select sum(Total) as Total_Amount from All_Orders where ID = '"+CustomerID.getText()+"'";
            String sql2 = "select sum(Rest) as Total_Rest_Amount from All_Orders where ID = '"+CustomerID.getText()+"'";
            
            PreparedStatement pst = con.prepareStatement(sql1);
            PreparedStatement sst = con.prepareStatement(sql2);
            ResultSet rs = pst.executeQuery();
            ResultSet res = sst.executeQuery();
            
            while(rs.next())
            {
                Total.setText(Integer.toString(rs.getInt("Total_Amount")));
            }
            while(res.next())
            {
                Rest.setText(Integer.toString(res.getInt("Total_Rest_Amount")));
            }
            Paid.setText(Integer.toString(Integer.parseInt(Total.getText()) - Integer.parseInt(Rest.getText())));
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    public void Specific_Transaction_Analysis(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql1, sql2, sql3;
            
            Date1 = sdf.format(First_Date.getDate());                
            Date2 = sdf.format(Last_Date.getDate());
            Date1 = Date1 + " 00:00:00.000";
            Date2 = Date2 + " 23:59:59.000";
            
            sql1 = "select sum(Total) as Total_Amount from All_Orders where ID = '"+CustomerID.getText()+"' and OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"'";
            sql2 = "select sum(Rest) as Total_Rest_Amount from All_Orders where ID = '"+CustomerID.getText()+"' and OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"'";
            
            PreparedStatement pst = con.prepareStatement(sql1);
            PreparedStatement sst = con.prepareStatement(sql2);
            ResultSet rs = pst.executeQuery();
            ResultSet res = sst.executeQuery();
            
            while(rs.next())
            {
                Total.setText(Integer.toString(rs.getInt("Total_Amount")));
            }
            while(res.next())
            {
                Rest.setText(Integer.toString(res.getInt("Total_Rest_Amount")));
            }
            Paid.setText(Integer.toString(Integer.parseInt(Total.getText()) - Integer.parseInt(Rest.getText())));
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    public void All_Order_Counting(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String type1 = "Pending", type2 = "Deliveried", type3 = "Cancelled";
            String sql1, sql2, sql3;
            
            sql1 = "Select count(OrderID) as Pending_Orders from All_Orders where OrderType = '"+type1+"' and ID = '"+CustomerID.getText()+"'";
            sql2 = "Select count(OrderID) as Delivered_Orders from All_Orders where OrderType = '"+type2+"' and ID = '"+CustomerID.getText()+"'";
            sql3 = "Select count(OrderID) as Cancelled_Orders from All_Orders where OrderType = '"+type3+"' and ID = '"+CustomerID.getText()+"'";
            
            PreparedStatement pst = con.prepareStatement(sql1);
            PreparedStatement sst = con.prepareStatement(sql2);
            PreparedStatement tst = con.prepareStatement(sql3);
            ResultSet rs = pst.executeQuery();
            ResultSet res = sst.executeQuery();
            ResultSet ress = tst.executeQuery();
            
            while(rs.next())
            {
                Pending.setText(Integer.toString(rs.getInt("Pending_Orders")));
            }
            while(res.next())
            {
                Delivered.setText(Integer.toString(res.getInt("Delivered_Orders")));
            }
            while(ress.next())
            {
                Cancelled.setText(Integer.toString(ress.getInt("Cancelled_Orders")));
            }
            Total_Orders.setText(Integer.toString(Integer.parseInt(Pending.getText()) + Integer.parseInt(Delivered.getText()) + Integer.parseInt(Cancelled.getText())));
            
        }catch(SQLException e){
        
            System.out.println(e);
            JOptionPane.showMessageDialog(null, e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    public void Specific_Order_Counting(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String type1 = "Pending", type2 = "Deliveried", type3 = "Cancelled";
            String sql1, sql2, sql3;
            
            Date1 = sdf.format(First_Date.getDate());                
            Date2 = sdf.format(Last_Date.getDate());
            Date1 = Date1 + " 00:00:00.000";
            Date2 = Date2 + " 23:59:59.000";
            sql1 = "Select count(OrderID) as Pending_Orders from All_Orders where ID = '"+CustomerID.getText()+"' and OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"' and OrderType = '"+type1+"'";
            sql2 = "Select count(OrderID) as Delivered_Orders from All_Orders where ID = '"+CustomerID.getText()+"' and OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"' and OrderType = '"+type2+"'";
            sql3 = "Select count(OrderID) as Cancelled_Orders from All_Orders where ID = '"+CustomerID.getText()+"' and OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"' and OrderType = '"+type3+"'";                
            
            PreparedStatement pst = con.prepareStatement(sql1);
            PreparedStatement sst = con.prepareStatement(sql2);
            PreparedStatement tst = con.prepareStatement(sql3);
            ResultSet rs = pst.executeQuery();
            ResultSet res = sst.executeQuery();
            ResultSet ress = tst.executeQuery();
            
            while(rs.next())
            {
                Pending.setText(Integer.toString(rs.getInt("Pending_Orders")));
            }
            while(res.next())
            {
                Delivered.setText(Integer.toString(res.getInt("Delivered_Orders")));
            }
            while(ress.next())
            {
                Cancelled.setText(Integer.toString(ress.getInt("Cancelled_Orders")));
            }
            Total_Orders.setText(Integer.toString(Integer.parseInt(Pending.getText()) + Integer.parseInt(Delivered.getText()) + Integer.parseInt(Cancelled.getText())));
            
        }catch(SQLException e){
        
            System.out.println(e);
            JOptionPane.showMessageDialog(null, e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel12 = new javax.swing.JLabel();
        CustomerID = new javax.swing.JTextField();
        Back = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        All_View = new javax.swing.JButton();
        Search = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        First_Date = new com.toedter.calendar.JDateChooser();
        Last_Date = new com.toedter.calendar.JDateChooser();
        jLabel8 = new javax.swing.JLabel();
        Total_Orders = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        CustomerName = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        Gender = new javax.swing.JTextField();
        Address = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        MobileNo = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        Pending = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        Delivered = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        Cancelled = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        Paid = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        Rest = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        Total = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        CancelledOrders = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        DeliveredOrders = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        PendingOrders = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        RootSelectionIcon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setText("Customer ID");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 110, -1));

        CustomerID.setEditable(false);
        CustomerID.setBackground(new java.awt.Color(249, 245, 242));
        CustomerID.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        CustomerID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CustomerIDActionPerformed(evt);
            }
        });
        getContentPane().add(CustomerID, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 110, 30));

        Back.setBackground(new java.awt.Color(249, 245, 242));
        Back.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Back.setText("Back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });
        getContentPane().add(Back, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 770, 140, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Logo_small.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 20, 70, -1));

        All_View.setBackground(new java.awt.Color(249, 245, 242));
        All_View.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        All_View.setText("All View");
        All_View.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                All_ViewActionPerformed(evt);
            }
        });
        getContentPane().add(All_View, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 120, 110, 30));

        Search.setBackground(new java.awt.Color(249, 245, 242));
        Search.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Search.setText("Search");
        Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchActionPerformed(evt);
            }
        });
        getContentPane().add(Search, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 120, 110, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setText("From (1st date)");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 100, 90, 20));

        First_Date.setBackground(new java.awt.Color(249, 245, 242));
        First_Date.setDateFormatString("yyyy-MM-dd");
        First_Date.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        First_Date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                First_DateMouseClicked(evt);
            }
        });
        getContentPane().add(First_Date, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, 210, 30));

        Last_Date.setBackground(new java.awt.Color(249, 245, 242));
        Last_Date.setDateFormatString("yyyy-MM-dd");
        Last_Date.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Last_Date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Last_DateMouseClicked(evt);
            }
        });
        getContentPane().add(Last_Date, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 120, 210, 30));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("Customer Name");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 160, -1, -1));

        Total_Orders.setEditable(false);
        Total_Orders.setBackground(new java.awt.Color(249, 245, 242));
        Total_Orders.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Total_Orders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Total_OrdersActionPerformed(evt);
            }
        });
        getContentPane().add(Total_Orders, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 100, 30));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel14.setText("Total Orders");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, 20));

        CustomerName.setEditable(false);
        CustomerName.setBackground(new java.awt.Color(249, 245, 242));
        CustomerName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        CustomerName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CustomerNameActionPerformed(evt);
            }
        });
        getContentPane().add(CustomerName, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 180, 200, 30));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("Contact Address");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 160, -1, -1));

        Gender.setEditable(false);
        Gender.setBackground(new java.awt.Color(249, 245, 242));
        Gender.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Gender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GenderActionPerformed(evt);
            }
        });
        getContentPane().add(Gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 180, 100, 30));

        Address.setEditable(false);
        Address.setBackground(new java.awt.Color(249, 245, 242));
        Address.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Address.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddressActionPerformed(evt);
            }
        });
        getContentPane().add(Address, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 180, 310, 30));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("Mobile Number");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 160, -1, -1));

        MobileNo.setEditable(false);
        MobileNo.setBackground(new java.awt.Color(249, 245, 242));
        MobileNo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(MobileNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 180, 130, 30));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("Gender");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 160, -1, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel16.setText("Pending");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 220, -1, 20));

        Pending.setEditable(false);
        Pending.setBackground(new java.awt.Color(249, 245, 242));
        Pending.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Pending.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PendingActionPerformed(evt);
            }
        });
        getContentPane().add(Pending, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 240, 90, 30));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel17.setText("Delivered");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 220, -1, 20));

        Delivered.setEditable(false);
        Delivered.setBackground(new java.awt.Color(249, 245, 242));
        Delivered.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Delivered.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeliveredActionPerformed(evt);
            }
        });
        getContentPane().add(Delivered, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 240, 90, 30));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel18.setText("Cancelled");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 220, -1, 20));

        Cancelled.setEditable(false);
        Cancelled.setBackground(new java.awt.Color(249, 245, 242));
        Cancelled.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Cancelled.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelledActionPerformed(evt);
            }
        });
        getContentPane().add(Cancelled, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 240, 90, 30));

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel19.setText("Total Paid (Taka)");
        getContentPane().add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 220, -1, 20));

        Paid.setEditable(false);
        Paid.setBackground(new java.awt.Color(249, 245, 242));
        Paid.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Paid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PaidActionPerformed(evt);
            }
        });
        getContentPane().add(Paid, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 240, 130, 30));

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel21.setText("Total Rest (Taka)");
        getContentPane().add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 220, -1, 20));

        Rest.setEditable(false);
        Rest.setBackground(new java.awt.Color(249, 245, 242));
        Rest.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Rest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RestActionPerformed(evt);
            }
        });
        getContentPane().add(Rest, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 240, 130, 30));

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel33.setText("Total Order (Taka)");
        getContentPane().add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 220, 120, 20));

        Total.setEditable(false);
        Total.setBackground(new java.awt.Color(249, 245, 242));
        Total.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        getContentPane().add(Total, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 240, 140, 30));

        jLabel2.setFont(new java.awt.Font("Monotype Corsiva", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Cancelled Orders");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 590, 890, 40));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel13.setText("To (Last date)");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 100, 90, 20));

        jLabel6.setFont(new java.awt.Font("Monotype Corsiva", 1, 24)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Pending Orders");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 890, 40));

        jLabel3.setFont(new java.awt.Font("Monotype Corsiva", 1, 24)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Customer Details");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 20, 370, 50));

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lebel_Small.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 930, -1));

        CancelledOrders.setBackground(new java.awt.Color(249, 245, 242));
        CancelledOrders.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        CancelledOrders.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Order ID", "Customer ID", "Dress ID", "Order Date", "Cancellation Date", "Penalty Rate"
            }
        ));
        CancelledOrders.setToolTipText("");
        CancelledOrders.setName(""); // NOI18N
        CancelledOrders.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CancelledOrdersMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(CancelledOrders);

        getContentPane().add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 630, 890, 120));

        DeliveredOrders.setBackground(new java.awt.Color(249, 245, 242));
        DeliveredOrders.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        DeliveredOrders.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Order ID", "Customer ID", "Dress ID", "Order Date", "Delivery Date", "Preparing Cost", "Discount (%)"
            }
        ));
        DeliveredOrders.setToolTipText("");
        DeliveredOrders.setName(""); // NOI18N
        DeliveredOrders.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DeliveredOrdersMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(DeliveredOrders);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, 890, 120));

        PendingOrders.setBackground(new java.awt.Color(249, 245, 242));
        PendingOrders.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PendingOrders.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Order ID", "Customer ID", "Dress ID", "Order Date", "Delivery Date", "Rest Amount", "Cost", "Discount (%)"
            }
        ));
        PendingOrders.setToolTipText("");
        PendingOrders.setName(""); // NOI18N
        PendingOrders.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PendingOrdersMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(PendingOrders);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 890, 120));

        jLabel7.setFont(new java.awt.Font("Monotype Corsiva", 1, 24)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Delivered Orders");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 890, 40));

        RootSelectionIcon.setBackground(new java.awt.Color(249, 245, 242));
        RootSelectionIcon.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        RootSelectionIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Customer_Details.jpg"))); // NOI18N
        getContentPane().add(RootSelectionIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 930, 830));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        
        new Customer_Info().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BackActionPerformed

    private void SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchActionPerformed
                    
            try{
                Date1 = sdf.format(First_Date.getDate());                
                Date2 = sdf.format(Last_Date.getDate());
                Date1 = Date1 + " 00:00:00.000";
                Date2 = Date2 + " 23:59:59.000";
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                OrderType = "Pending";
                String sql1 = "Select * from All_Orders where ID = '"+CustomerID.getText()+"' and OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"' and OrderType = '"+OrderType+"' order by OrderDate asc";
                OrderType = "Deliveried";
                String sql2 = "Select * from All_Orders where ID = '"+CustomerID.getText()+"' and OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"' and OrderType = '"+OrderType+"' order by OrderDate desc";
                OrderType = "Cancelled";
                String sql3 = "Select * from All_Orders where ID = '"+CustomerID.getText()+"' and OrderDate >= '"+Date1+"' and OrderDate <= '"+Date2+"' and OrderType = '"+OrderType+"' order by OrderDate desc";
                
                PreparedStatement pst = con.prepareStatement(sql1);
                PreparedStatement qst = con.prepareStatement(sql2);
                PreparedStatement rst = con.prepareStatement(sql3);

                ResultSet rs = pst.executeQuery();  
                ResultSet res = qst.executeQuery();  
                ResultSet ress = rst.executeQuery();  
                
                Specific_Transaction_Analysis();
                Specific_Order_Counting();            
                PendingOrders.setModel(new DefaultTableModel(null, new String[] {"Order ID","Customer ID","Dress ID","Order Date","Delivery Date","Rest Amount","Cost","Discount (%)"}));
                DeliveredOrders.setModel(new DefaultTableModel(null, new String[] {"Order ID","Customer ID","Dress ID","Order Date","Delivery Date","Preparing Cost","Discount (%)"}));
                CancelledOrders.setModel(new DefaultTableModel(null, new String[] {"Order ID","Customer ID","Dress ID","Order Date","Cancellation Date","Penalty Rate"}));
                while(rs.next())
                {
                    String tbData[] = {Integer.toString(rs.getInt("OrderID")),
                                        rs.getString("ID"),
                                        Integer.toString(rs.getInt("DressID")),                                    
                                        rs.getString("OrderDate"),
                                        rs.getString("DeliveryDate"),
                                        Integer.toString(rs.getInt("Rest")),
                                        Integer.toString(rs.getInt("Total")),
                                        Integer.toString(rs.getInt("Discount"))};
                    DefaultTableModel tbModel = (DefaultTableModel) PendingOrders.getModel();
                    tbModel.addRow(tbData);
                }
                while(res.next())
                {
                    String tbData[] = {Integer.toString(res.getInt("OrderID")),
                                        res.getString("ID"),
                                        Integer.toString(res.getInt("DressID")),                                    
                                        res.getString("OrderDate"),
                                        res.getString("DeliveryDate"),
                                        Integer.toString(res.getInt("Total")),
                                        Integer.toString(res.getInt("Discount"))};
                    DefaultTableModel tbModel = (DefaultTableModel) DeliveredOrders.getModel();
                    tbModel.addRow(tbData);
                }
                while(ress.next())
                {
                    String tbData[] = {Integer.toString(ress.getInt("OrderID")),
                                        ress.getString("ID"),
                                        Integer.toString(ress.getInt("DressID")),                                    
                                        ress.getString("OrderDate"),
                                        ress.getString("DeliveryDate"),
                                        Integer.toString(ress.getInt("Total"))};
                    DefaultTableModel tbModel = (DefaultTableModel) CancelledOrders.getModel();
                    tbModel.addRow(tbData);
                }
                
            }catch(SQLException e){
                JOptionPane.showMessageDialog(null, "Select the specific date !"); 
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Select the specific date !"); 
            }    
    }//GEN-LAST:event_SearchActionPerformed

    private void First_DateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_First_DateMouseClicked
        All_View();
    }//GEN-LAST:event_First_DateMouseClicked

    private void Last_DateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Last_DateMouseClicked
        All_View();
    }//GEN-LAST:event_Last_DateMouseClicked

    private void All_ViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_All_ViewActionPerformed
        All_View();
    }//GEN-LAST:event_All_ViewActionPerformed

    private void PendingOrdersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PendingOrdersMouseClicked
        
    }//GEN-LAST:event_PendingOrdersMouseClicked

    private void DeliveredOrdersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeliveredOrdersMouseClicked
        
    }//GEN-LAST:event_DeliveredOrdersMouseClicked

    private void CancelledOrdersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CancelledOrdersMouseClicked
        
    }//GEN-LAST:event_CancelledOrdersMouseClicked

    private void CustomerNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CustomerNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CustomerNameActionPerformed

    private void AddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AddressActionPerformed

    private void PendingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PendingActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PendingActionPerformed

    private void DeliveredActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeliveredActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DeliveredActionPerformed

    private void CancelledActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelledActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CancelledActionPerformed

    private void PaidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PaidActionPerformed

    private void RestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RestActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RestActionPerformed

    private void GenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GenderActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_GenderActionPerformed

    private void CustomerIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CustomerIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CustomerIDActionPerformed

    private void Total_OrdersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Total_OrdersActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Total_OrdersActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Customer_Details().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Address;
    private javax.swing.JButton All_View;
    private javax.swing.JButton Back;
    private javax.swing.JTextField Cancelled;
    private javax.swing.JTable CancelledOrders;
    private javax.swing.JTextField CustomerID;
    private javax.swing.JTextField CustomerName;
    private javax.swing.JTextField Delivered;
    private javax.swing.JTable DeliveredOrders;
    private com.toedter.calendar.JDateChooser First_Date;
    private javax.swing.JTextField Gender;
    private com.toedter.calendar.JDateChooser Last_Date;
    private javax.swing.JTextField MobileNo;
    private javax.swing.JTextField Paid;
    private javax.swing.JTextField Pending;
    private javax.swing.JTable PendingOrders;
    private javax.swing.JTextField Rest;
    private javax.swing.JLabel RootSelectionIcon;
    private javax.swing.JButton Search;
    private javax.swing.JTextField Total;
    private javax.swing.JTextField Total_Orders;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    // End of variables declaration//GEN-END:variables

    private String getString(String fromInput) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void TicketGenerate(String text, String text0, String text1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private String getText(String format) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}