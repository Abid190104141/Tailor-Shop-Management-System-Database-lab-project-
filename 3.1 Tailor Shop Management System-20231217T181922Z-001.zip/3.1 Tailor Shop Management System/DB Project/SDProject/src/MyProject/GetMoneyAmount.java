package MyProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class GetMoneyAmount extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;
    
    String OrderID = null;
    String Cost = null;
    int Paid = 0;
    int PenaltyRate = 0;
    
    public GetMoneyAmount() {
        initComponents();
    }
    public GetMoneyAmount(String OrderID, String Rest, String Cost) {
        initComponents();
        
        this.OrderID = OrderID;
        this.Cost = Cost;
        PreparingCost.setText(Cost);
        PenaltyRate = (int)(Float.parseFloat(Cost)*15/100);
        Penalty.setText(Integer.toString(PenaltyRate));
        Paid = Integer.parseInt(Cost) - Integer.parseInt(Rest);
        PaidAmount.setText(Integer.toString(Paid));
        GetMoney.setText(Integer.toString(Paid - PenaltyRate));       
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        Agreed = new javax.swing.JButton();
        PreparingCost = new javax.swing.JTextField();
        Penalty = new javax.swing.JTextField();
        Cancel = new javax.swing.JButton();
        GetMoney = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        PaidAmount = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        Payment_Icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        jLabel3.setText("Preparing Cost");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 140, -1, 50));

        jLabel4.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        jLabel4.setText("Paid Amount");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 280, 130, 50));

        jLabel5.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        jLabel5.setText("After All");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 350, 130, 50));

        Agreed.setBackground(new java.awt.Color(249, 245, 242));
        Agreed.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        Agreed.setText("Agreed");
        Agreed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgreedActionPerformed(evt);
            }
        });
        getContentPane().add(Agreed, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 440, 150, 40));

        PreparingCost.setEditable(false);
        PreparingCost.setBackground(new java.awt.Color(249, 245, 242));
        PreparingCost.setFont(new java.awt.Font("Agency FB", 0, 24)); // NOI18N
        PreparingCost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PreparingCostActionPerformed(evt);
            }
        });
        getContentPane().add(PreparingCost, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 140, 220, 50));

        Penalty.setEditable(false);
        Penalty.setBackground(new java.awt.Color(249, 245, 242));
        Penalty.setFont(new java.awt.Font("Agency FB", 0, 24)); // NOI18N
        Penalty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PenaltyActionPerformed(evt);
            }
        });
        getContentPane().add(Penalty, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 210, 220, 50));

        Cancel.setBackground(new java.awt.Color(249, 245, 242));
        Cancel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        Cancel.setText("Cancel");
        Cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelActionPerformed(evt);
            }
        });
        getContentPane().add(Cancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 440, 140, 40));

        GetMoney.setEditable(false);
        GetMoney.setBackground(new java.awt.Color(249, 245, 242));
        GetMoney.setFont(new java.awt.Font("Agency FB", 0, 24)); // NOI18N
        GetMoney.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GetMoneyActionPerformed(evt);
            }
        });
        getContentPane().add(GetMoney, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 350, 220, 50));

        jLabel1.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        jLabel1.setText("Taka");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 140, 50, 50));

        jLabel6.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        jLabel6.setText("Taka");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 280, -1, 50));

        jLabel7.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        jLabel7.setText("Taka");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 350, -1, 50));

        jLabel2.setFont(new java.awt.Font("Monotype Corsiva", 1, 36)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Rest Money");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 40, 380, 50));

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lebel_Small.png"))); // NOI18N
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 660, -1));

        PaidAmount.setEditable(false);
        PaidAmount.setBackground(new java.awt.Color(249, 245, 242));
        PaidAmount.setFont(new java.awt.Font("Agency FB", 0, 24)); // NOI18N
        PaidAmount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PaidAmountActionPerformed(evt);
            }
        });
        getContentPane().add(PaidAmount, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 280, 220, 50));

        jLabel9.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        jLabel9.setText("Penalty ( 15% )");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, 130, 50));

        jLabel10.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        jLabel10.setText("Taka");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 210, -1, 50));

        Payment_Icon.setBackground(new java.awt.Color(255, 255, 255));
        Payment_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Middle.jpg"))); // NOI18N
        getContentPane().add(Payment_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 660, 510));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PreparingCostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PreparingCostActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PreparingCostActionPerformed

    private void PenaltyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PenaltyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PenaltyActionPerformed

    private void CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelActionPerformed
        new Pending_Orders().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_CancelActionPerformed

    @SuppressWarnings({"deprecation", "deprecation"})
    private void AgreedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgreedActionPerformed
           
        int result = JOptionPane.showConfirmDialog(this,"Do you want to Cancel the order ?","Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
                
        if(result == JOptionPane.YES_OPTION){
           
           JOptionPane.showMessageDialog(null, "You have to pay " + GetMoney.getText() + " taka to the customer."); 
           Date CurrentDate = new Date();
           SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
           String Date = sdf.format(CurrentDate);
           try{
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String type = "Cancelled";
                int zero = 0;
                String sql1 = "update All_Orders set DeliveryDate = '"+Date+"', Rest = '"+zero+"', Total = '"+PenaltyRate+"', OrderType = '"+type+"' where OrderID = '"+OrderID+"'";
                String sql2 = "delete from Measurements where OrderID = '"+OrderID+"'";
                
                PreparedStatement pst = con.prepareStatement(sql1);
                PreparedStatement sst = con.prepareStatement(sql2);
                
                pst.executeUpdate();
                sst.executeUpdate();
                
                JOptionPane.showMessageDialog(null, "The order has been Cancelled !"); 
                new Pending_Orders().setVisible(true);
                this.setVisible(false);
            
            }catch(SQLException e){

                System.out.println(e);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Dress_Category.class.getName()).log(Level.SEVERE, null, ex);
            }               
        }   
    }//GEN-LAST:event_AgreedActionPerformed

    private void GetMoneyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GetMoneyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_GetMoneyActionPerformed

    private void PaidAmountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaidAmountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PaidAmountActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GetMoneyAmount().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Agreed;
    private javax.swing.JButton Cancel;
    private javax.swing.JTextField GetMoney;
    private javax.swing.JTextField PaidAmount;
    private javax.swing.JLabel Payment_Icon;
    private javax.swing.JTextField Penalty;
    private javax.swing.JTextField PreparingCost;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    // End of variables declaration//GEN-END:variables
}
