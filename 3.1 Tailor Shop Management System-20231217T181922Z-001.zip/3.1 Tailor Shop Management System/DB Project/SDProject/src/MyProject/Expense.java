package MyProject;

import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public final class Expense extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;
    
    int SI_no = 0;
    String Date1 = null;
    String Date2 = null;
    String Current_Date = null;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    SimpleDateFormat tdf = new SimpleDateFormat("yyyy-MM-dd");
    
    public Expense() {
        
        initComponents();        
        All_View();
    }
    
    public void All_View(){
        
        try{
            Current_Date_and_Time();
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql = "Select * from Expenses order by Date desc";
            PreparedStatement sst = con.prepareStatement(sql);
            
            ResultSet res = sst.executeQuery();
            All_Expenses.setModel(new DefaultTableModel(null, new String[] {"SI No", "Issue", "Cost Amount", "Short Description", "Date"}));

            while(res.next())
            {
                    String tbData[] = {Integer.toString(res.getInt("SI_no")),
                                        res.getString("Issue"),
                                        Integer.toString(res.getInt("Cost_Ammount")),
                                        res.getString("Description"),
                                        res.getString("Date")};
                    DefaultTableModel tbModel = (DefaultTableModel) All_Expenses.getModel();
                    tbModel.addRow(tbData);
            }
            Date1 = null;
            Date2 = null;
            First_Date.setCalendar(null);
            Last_Date.setCalendar(null);
            Issue.setText(null);
            Amount.setText(null);
            Description.setText(null);
            
        }catch(SQLException e){
        
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Expense.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void Current_Date_and_Time(){
        Date CurrentDate = new Date();
        setDate.setText(sdf.format(CurrentDate));        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        All_Expenses = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Issue = new javax.swing.JTextField();
        Amount = new javax.swing.JTextField();
        MainMenu = new javax.swing.JButton();
        Add = new javax.swing.JButton();
        Update = new javax.swing.JButton();
        setDate = new javax.swing.JTextField();
        Delete = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        Search = new javax.swing.JButton();
        First_Date = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        Description = new javax.swing.JTextArea();
        jLabel16 = new javax.swing.JLabel();
        Last_Date = new com.toedter.calendar.JDateChooser();
        All_View = new javax.swing.JButton();
        Info_Icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        All_Expenses.setBackground(new java.awt.Color(249, 245, 242));
        All_Expenses.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "SI No", "Issue", "Cost Amount", "Short Description", "Date"
            }
        ));
        All_Expenses.setToolTipText("");
        All_Expenses.setName(""); // NOI18N
        All_Expenses.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                All_ExpensesMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(All_Expenses);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 170, 640, 240));

        jLabel2.setFont(new java.awt.Font("Monotype Corsiva", 1, 28)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Expenses");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 20, 380, 60));

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lebel_Small.png"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 720, 90));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("Issue");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 430, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Short Description");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 430, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("Date");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 490, -1, -1));

        Issue.setBackground(new java.awt.Color(249, 245, 242));
        Issue.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Issue.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                IssueMouseClicked(evt);
            }
        });
        Issue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IssueActionPerformed(evt);
            }
        });
        getContentPane().add(Issue, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 450, 310, 30));

        Amount.setBackground(new java.awt.Color(249, 245, 242));
        Amount.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Amount.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AmountMouseClicked(evt);
            }
        });
        getContentPane().add(Amount, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 510, 130, 30));

        MainMenu.setBackground(new java.awt.Color(249, 245, 242));
        MainMenu.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        MainMenu.setText("Back");
        MainMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MainMenuActionPerformed(evt);
            }
        });
        getContentPane().add(MainMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 620, 180, 40));

        Add.setBackground(new java.awt.Color(249, 245, 242));
        Add.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Add.setText("Add a new");
        Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddActionPerformed(evt);
            }
        });
        getContentPane().add(Add, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 560, 140, 40));

        Update.setBackground(new java.awt.Color(249, 245, 242));
        Update.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Update.setText("Update");
        Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateActionPerformed(evt);
            }
        });
        getContentPane().add(Update, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 560, 140, 40));

        setDate.setBackground(new java.awt.Color(249, 245, 242));
        setDate.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        setDate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                setDateMouseClicked(evt);
            }
        });
        setDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                setDateActionPerformed(evt);
            }
        });
        getContentPane().add(setDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 510, 160, 30));

        Delete.setBackground(new java.awt.Color(249, 245, 242));
        Delete.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Delete.setText("Delete");
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });
        getContentPane().add(Delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 560, 140, 40));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Cost Ammount (Taka)");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 490, -1, -1));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setText("From (1st date)");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 110, -1, 20));

        Search.setBackground(new java.awt.Color(249, 245, 242));
        Search.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Search.setText("Search");
        Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchActionPerformed(evt);
            }
        });
        getContentPane().add(Search, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 130, 80, 30));

        First_Date.setBackground(new java.awt.Color(249, 245, 242));
        First_Date.setDateFormatString("yyyy-MM-dd");
        First_Date.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        First_Date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                First_DateMouseClicked(evt);
            }
        });
        getContentPane().add(First_Date, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 130, 210, 30));

        Description.setBackground(new java.awt.Color(249, 245, 242));
        Description.setColumns(20);
        Description.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 14)); // NOI18N
        Description.setLineWrap(true);
        Description.setRows(5);
        Description.setTabSize(4);
        Description.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DescriptionMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Description);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 450, 310, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel16.setText("To (Last date)");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 110, -1, 20));

        Last_Date.setBackground(new java.awt.Color(249, 245, 242));
        Last_Date.setDateFormatString("yyyy-MM-dd");
        Last_Date.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Last_Date.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Last_DateMouseClicked(evt);
            }
        });
        getContentPane().add(Last_Date, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 130, 210, 30));

        All_View.setBackground(new java.awt.Color(249, 245, 242));
        All_View.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        All_View.setText("All View");
        All_View.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                All_ViewActionPerformed(evt);
            }
        });
        getContentPane().add(All_View, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 80, 30));

        Info_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Expense.jpg"))); // NOI18N
        getContentPane().add(Info_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 720, 680));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void All_ExpensesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_All_ExpensesMouseClicked
        int i = All_Expenses.getSelectedRow();
        TableModel model = All_Expenses.getModel();
        
        SI_no = Integer.parseInt((String) model.getValueAt(i, 0));
        Issue.setText((String) model.getValueAt(i, 1));
        Amount.setText((String) model.getValueAt(i, 2));
        Description.setText((String) model.getValueAt(i, 3));
        setDate.setText((String) model.getValueAt(i, 4));
    }//GEN-LAST:event_All_ExpensesMouseClicked
    
    
    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
        //Delete from database
        int result = JOptionPane.showConfirmDialog(this,"Do you want to delete ?","Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
                
        if(result == JOptionPane.YES_OPTION){
            
            try{
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql = "delete from Expenses where SI_no = '"+SI_no+"'";

                PreparedStatement pst = con.prepareStatement(sql);
                pst.executeUpdate();

                JOptionPane.showMessageDialog(null, "The selected info has been deleted !"); 

            }catch(SQLException e){

                System.out.println(e);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Dress_Category.class.getName()).log(Level.SEVERE, null, ex);
            }    

            All_View();              
        }
    }//GEN-LAST:event_DeleteActionPerformed

    private void MainMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MainMenuActionPerformed
        
        new Menu().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_MainMenuActionPerformed

    private void UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateActionPerformed
        //Update in database        
        if(setDate.getText().isEmpty() || Issue.getText().isEmpty()|| Amount.getText().isEmpty() || Description.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Enter the all the Information !");
        }
        else
        {
           try{
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);

                String sql = "update Expenses set Issue = '"+Issue.getText()+"', Cost_Ammount = '"+Integer.parseInt(Amount.getText())+"', Description = '"+Description.getText()+"', Date = '"+setDate.getText()+"' where SI_no = '"+SI_no+"'";

                PreparedStatement pst = con.prepareStatement(sql);

                pst.executeUpdate();

                JOptionPane.showMessageDialog(null, "The updated info has been added !"); 
            
            }catch(SQLException e){

                System.out.println(e);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Dress_Category.class.getName()).log(Level.SEVERE, null, ex);
            }    

            All_View(); 
        }
    }//GEN-LAST:event_UpdateActionPerformed

    private void IssueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IssueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IssueActionPerformed

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        //Add to database
        if(Issue.getText().isEmpty()|| Amount.getText().isEmpty() || Description.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Enter the all the Information !");
        }
        else
        {
            try{
                Date CurrentDate = new Date();
                Current_Date = sdf.format(CurrentDate);
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
                Connection con = DriverManager.getConnection(url);
                String sql = "insert into Expenses(Issue, Cost_Ammount, Description, Date) values ('"+Issue.getText()+"','"+Integer.parseInt(Amount.getText())+"','"+Description.getText()+"','"+Current_Date+"')";

                PreparedStatement pst = con.prepareStatement(sql);

                pst.executeUpdate();

                JOptionPane.showMessageDialog(null, "The inserted info has been added !"); 

            }catch(SQLException e){

                System.out.println(e);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Dress_Category.class.getName()).log(Level.SEVERE, null, ex);
            }

            All_View();
        }
    }//GEN-LAST:event_AddActionPerformed

    private void SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchActionPerformed
        
        try{
            Date1 = tdf.format(First_Date.getDate());                
            Date2 = tdf.format(Last_Date.getDate()); 
            Date1 = Date1 + " 00:00:00.000";
            Date2 = Date2 + " 23:59:59.000"; 
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url="jdbc:sqlserver://localhost:1433;databaseName=TailorShopManagementSystem;user=sa;password=p@ssword13";
            Connection con = DriverManager.getConnection(url);
            String sql = "Select * from Expenses where Date >= '"+Date1+"' and Date <= '"+Date2+"' order by Date desc";
            PreparedStatement pst = con.prepareStatement(sql);            
            ResultSet res = pst.executeQuery();
            All_Expenses.setModel(new DefaultTableModel(null, new String[] {"SI No", "Issue", "Cost Amount", "Short Description", "Date"}));

            while(res.next())
            {
                String tbData[] = {Integer.toString(res.getInt("SI_no")),
                                   res.getString("Issue"),
                                   Integer.toString(res.getInt("Cost_Ammount")),
                                   res.getString("Description"),
                                   res.getString("Date")};
                DefaultTableModel tbModel = (DefaultTableModel) All_Expenses.getModel();
                tbModel.addRow(tbData);
            }
                
            Issue.setText(null);
            Amount.setText(null);
            Description.setText(null);

        }catch(SQLException e){

            System.out.println(e);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Select the specific date !"); 
        }
    }//GEN-LAST:event_SearchActionPerformed

    private void First_DateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_First_DateMouseClicked
        // TODO add your handling code here:     
    }//GEN-LAST:event_First_DateMouseClicked

    private void setDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_setDateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_setDateActionPerformed

    private void Last_DateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Last_DateMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_Last_DateMouseClicked

    private void All_ViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_All_ViewActionPerformed
        All_View();
    }//GEN-LAST:event_All_ViewActionPerformed

    private void IssueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_IssueMouseClicked
        Current_Date_and_Time();
    }//GEN-LAST:event_IssueMouseClicked

    private void AmountMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AmountMouseClicked
        Current_Date_and_Time();
    }//GEN-LAST:event_AmountMouseClicked

    private void DescriptionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DescriptionMouseClicked
        Current_Date_and_Time();
    }//GEN-LAST:event_DescriptionMouseClicked

    private void setDateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_setDateMouseClicked
        Current_Date_and_Time();
    }//GEN-LAST:event_setDateMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Expense().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JTable All_Expenses;
    private javax.swing.JButton All_View;
    private javax.swing.JTextField Amount;
    private javax.swing.JButton Delete;
    private javax.swing.JTextArea Description;
    private com.toedter.calendar.JDateChooser First_Date;
    private javax.swing.JLabel Info_Icon;
    private javax.swing.JTextField Issue;
    private com.toedter.calendar.JDateChooser Last_Date;
    private javax.swing.JButton MainMenu;
    private javax.swing.JButton Search;
    private javax.swing.JButton Update;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField setDate;
    // End of variables declaration//GEN-END:variables

    private String getString(String fromInput) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void TicketGenerate(String text, String text0, String text1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private String getText(String format) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}