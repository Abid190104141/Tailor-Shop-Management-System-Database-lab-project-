package MyProject;

public class All_Orders extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;

    public All_Orders() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Pending_Orders = new javax.swing.JButton();
        Delivered_Orders = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        Cancelled_Orders = new javax.swing.JButton();
        Back = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Menu_icon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Main Menu");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pending_Orders.setBackground(new java.awt.Color(249, 245, 242));
        Pending_Orders.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Pending_Orders.setText("Pending Orders List");
        Pending_Orders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Pending_OrdersActionPerformed(evt);
            }
        });
        getContentPane().add(Pending_Orders, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 170, 230, 50));

        Delivered_Orders.setBackground(new java.awt.Color(249, 245, 242));
        Delivered_Orders.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Delivered_Orders.setText("Delivered Orders List");
        Delivered_Orders.setToolTipText("");
        Delivered_Orders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Delivered_OrdersActionPerformed(evt);
            }
        });
        getContentPane().add(Delivered_Orders, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 250, 230, 50));

        jLabel2.setFont(new java.awt.Font("Monotype Corsiva", 1, 36)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("All Types Orders");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 760, 80));

        Cancelled_Orders.setBackground(new java.awt.Color(249, 245, 242));
        Cancelled_Orders.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Cancelled_Orders.setText("Cancelled Orders List");
        Cancelled_Orders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cancelled_OrdersActionPerformed(evt);
            }
        });
        getContentPane().add(Cancelled_Orders, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 330, 230, 50));

        Back.setBackground(new java.awt.Color(249, 245, 242));
        Back.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Back.setText("Main Menu");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });
        getContentPane().add(Back, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 410, 230, 50));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Logo_large.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 150, 260, 300));

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lebel_Bar.png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 760, 110));

        Menu_icon.setBackground(new java.awt.Color(255, 255, 255));
        Menu_icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Orders.jpg"))); // NOI18N
        getContentPane().add(Menu_icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, 540));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Cancelled_OrdersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Cancelled_OrdersActionPerformed
        
        new Cancelled_Orders().setVisible(true);
        this.setVisible(false);     
    }//GEN-LAST:event_Cancelled_OrdersActionPerformed

    private void Pending_OrdersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Pending_OrdersActionPerformed
        
        new Pending_Orders().setVisible(true);
        this.setVisible(false);        
    }//GEN-LAST:event_Pending_OrdersActionPerformed

    private void Delivered_OrdersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Delivered_OrdersActionPerformed
       
        new Deliveried_Orders().setVisible(true);
        this.setVisible(false);         
    }//GEN-LAST:event_Delivered_OrdersActionPerformed

    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        
        new Menu().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(All_Orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(All_Orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(All_Orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(All_Orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new All_Orders().setVisible(true);
            }
            
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Back;
    private javax.swing.JButton Cancelled_Orders;
    private javax.swing.JButton Delivered_Orders;
    private javax.swing.JLabel Menu_icon;
    private javax.swing.JButton Pending_Orders;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
