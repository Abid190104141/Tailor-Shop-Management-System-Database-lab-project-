package MyProject;

import javax.swing.JOptionPane;

public class Verification extends javax.swing.JFrame {

    private static final long serialVersionUID = 1L;
    
    String Verification_Code;
    String From;
    
    public Verification() {
        initComponents();
    }
    
    public Verification(String From, String Code) {
        initComponents();
        
        this.From = From;
        Verification_Code = Code;
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jPanel1 = new javax.swing.JPanel();
        VerificationCode = new javax.swing.JTextField();
        Verify = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        Back = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        jScrollPane2.setViewportView(jTextPane1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        VerificationCode.setBackground(new java.awt.Color(251, 250, 246));
        VerificationCode.setFont(new java.awt.Font("DejaVu Serif", 1, 14)); // NOI18N
        VerificationCode.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        VerificationCode.setText("Enter the verification code");
        VerificationCode.setBorder(null);
        VerificationCode.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        VerificationCode.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                VerificationCodeFocusGained(evt);
            }
        });
        VerificationCode.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VerificationCodeMouseClicked(evt);
            }
        });
        VerificationCode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VerificationCodeActionPerformed(evt);
            }
        });
        jPanel1.add(VerificationCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 90, 230, 34));

        Verify.setBackground(new java.awt.Color(249, 245, 242));
        Verify.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Verify.setText("Verify");
        Verify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VerifyActionPerformed(evt);
            }
        });
        jPanel1.add(Verify, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 180, 100, 40));

        jSeparator1.setBackground(new java.awt.Color(0, 255, 255));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 130, 230, 10));

        Back.setBackground(new java.awt.Color(249, 245, 242));
        Back.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Back.setText("Back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });
        jPanel1.add(Back, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, 100, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Verification.jpg"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 260));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void VerificationCodeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_VerificationCodeFocusGained
        
    }//GEN-LAST:event_VerificationCodeFocusGained

    private void VerificationCodeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VerificationCodeMouseClicked
        // TODO add your handling code here:
        VerificationCode.setText("");
    }//GEN-LAST:event_VerificationCodeMouseClicked

    private void VerificationCodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VerificationCodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_VerificationCodeActionPerformed

    private void VerifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VerifyActionPerformed
        if(VerificationCode.getText().trim().isEmpty() || VerificationCode.getText().equals("Enter the verification code"))
        {
            JOptionPane.showMessageDialog(null, "Enter the verification code !!!");
        }
        else if(VerificationCode.getText().equals(Verification_Code))
        {
            new Admin_Profile(From).setVisible(true);
            this.setVisible(false);    
        }else
        {
            JOptionPane.showMessageDialog(null, "Entered code is wrong !!! Check again ...");
        }
    }//GEN-LAST:event_VerifyActionPerformed

    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        // TODO add your handling code here:
        if(From.equals("Sign IN"))
        {
            new SignIN().setVisible(true);            
            
        }else if(From.equals("Information"))
        {
            new Information().setVisible(true);
        }
        this.setVisible(false);
    }//GEN-LAST:event_BackActionPerformed

    /**
     * 
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Verification().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Back;
    private javax.swing.JTextField VerificationCode;
    private javax.swing.JButton Verify;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextPane jTextPane1;
    // End of variables declaration//GEN-END:variables
}
